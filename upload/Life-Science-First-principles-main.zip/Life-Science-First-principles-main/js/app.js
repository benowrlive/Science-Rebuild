/* Boot + router. Hash routing because it needs no server rewrite rules and
   works identically from a file server, a static host and the service worker. */

import { progress, subscribe } from "./state.js";
import { applyRoot, needsPicker, needsWelcome, needsIntro } from "./level.js";
import { loadCurriculum } from "./curriculum.js";
import { atlas, module as moduleScreen, levelPicker, welcome } from "./screens.js";
import { el, mount } from "./el.js";

const host = document.getElementById("main");
const live = document.getElementById("live");

/* Lesson code is imported only when a lesson route is hit, so a child on the
   Atlas never downloads the runner, the quiz component or the review flow. */
const lazyLesson = (...args) => import("./lesson/view.js").then((m) => m.lessonView(...args));
const lazyReview = () => import("./lesson/review.js").then((m) => m.reviewView());
/* Me is a route too: badges, the specimen shelf and every setting are worth
   several kilobytes that a child booting to the Atlas has no use for. (D73) */
const lazyMe = () => import("./me.js").then((m) => m.me());
/* The opening is lazy for the same reason as everything else here: it is played
   once and then never again, and a child returning to the Atlas on day two
   should not be downloading it. (D81) */
const lazyIntro = () => import("./intro.js").then((m) => m.intro());

/* `live: true` marks a route that owns its own DOM across state changes.
   Without it, awarding XP mid-lesson dispatched fp:change, the subscriber
   repainted the route, and the child was thrown back to stage one by their own
   correct answer. Stateless screens (Atlas, module, Me) still repaint on every
   change, which is what keeps them honest. */
const routes = [
  [/^\/?$/, atlas],
  [/^\/m\/([\w-]+)$/, moduleScreen],
  [/^\/l\/([\w-]+)\/(\d+)$/, lazyLesson, { live: true }],
  [/^\/review$/, lazyReview, { live: true }],
  [/^\/me$/, lazyMe],
  [/^\/intro$/, lazyIntro],
];

let liveRoute = false;

function resolve() {
  const path = location.hash.replace(/^#/, "") || "/";
  for (const [re, view, opts] of routes) {
    const m = path.match(re);
    if (m) {
      liveRoute = !!opts?.live;
      return () => view(...m.slice(1));
    }
  }
  liveRoute = false;
  return atlas;
}

let current = "";
let painted = false;

async function paint() {
  // A state change repaints the screen, which would otherwise throw a keyboard
  // user back to the heading every time they touched a radio. Elements that
  // must survive a repaint carry data-fk.
  const keep = document.activeElement?.closest?.("[data-fk]")?.dataset.fk;

  /* Two gates before the router, in order: say what this is, then ask how the
     words should read. Both are one-time and both override the hash, because a
     cold start has nothing to route to yet. */
  const view = needsWelcome() ? welcome
    : needsIntro() ? lazyIntro
    : needsPicker() ? levelPicker : resolve();
  // A view may be async (lazily-imported lesson code). Awaiting it here keeps
  // every caller synchronous-looking and means there is exactly one paint path.
  /* A view that throws used to render NOTHING — a blank page, no console error,
     no clue. A missing import in a lazily-loaded screen was invisible until I
     called the function by hand in a browser. A screen that cannot render must
     say so; silence is the one response that helps nobody. (D73) */
  let painted$;
  try {
    painted$ = await view();
  } catch (e) {
    console.error("view failed", e);
    painted$ = [
      el("h1", { text: "That screen did not load" }),
      el("p", { class: "notice notice--soft", text:
        "Something is wrong at our end, not yours. Your progress is safe — it is stored on this device." }),
      el("a", { class: "back pressable", href: "#/" }, el("span", { text: "Back to the Atlas" })),
    ];
  }
  mount(host, painted$);

  const restored = keep && host.querySelector(`[data-fk="${CSS.escape(keep)}"]`);
  if (restored) { restored.focus({ preventScroll: true }); return; }

  const heading = host.querySelector("h1");
  if (!heading) return;
  heading.setAttribute("tabindex", "-1");

  // Focus is moved on route changes so keyboard and screen-reader users are not
  // left wherever the last click was — but NOT on the very first paint, because
  // grabbing focus on load puts the skip link behind the user and makes it
  // unreachable by forward tabbing.
  if (painted) {
    heading.focus({ preventScroll: true });
    live.textContent = heading.textContent;
  }
  painted = true;
  window.scrollTo(0, 0);
}

function render() {
  const next = location.hash;
  const changed = next !== current;
  current = next;
  // Role 2 (spatial): shared-element transition so the child knows where they
  // came from. Progressive enhancement — unsupported browsers just repaint.
  if (changed && document.startViewTransition && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
    document.startViewTransition(() => paint());
  } else {
    paint();
  }
}

addEventListener("hashchange", render);
subscribe(() => {
  applyRoot();
  // A live route re-renders itself; repainting it here would destroy the
  // position the child is standing in.
  if (!liveRoute) paint();
});

(async function boot() {
  applyRoot();
  try {
    await loadCurriculum();
    render();
  } catch (err) {
    host.textContent = "Could not load the curriculum. Check your connection and reload.";
    console.error(err);
  } finally {
    // Must run on the failure path too, or the error message above is hidden by
    // the very rule that stops the empty shell flashing.
    document.body.dataset.ready = "";
  }

  /* A DEPLOY HAS TO REACH THE CHILD. Registering was the whole of this and it is
     not enough: the worker serves the shell from its cache, so a returning visitor
     keeps the OLD app until a new worker has installed, activated, claimed, and
     then been asked for a fresh page. Measured on the real upgrade — old build in
     the cache, new build on the server — that took THREE page loads. The first two
     showed the previous version with nothing to say so. A fix shipped on Monday
     reached the person who reported it on Wednesday, and looked like it had never
     shipped at all. (D80)

     controllerchange fires the moment the new worker takes over. Reload once, and
     the deploy lands on the first return visit instead of the third.

     `refreshing` guards the reload loop. The `controller` test guards the FIRST
     install: clients.claim() on a page that had no controller also fires this, and
     reloading a child who has simply arrived would be a flicker for nothing. */
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    let refreshing = false;
    const hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (refreshing || !hadController) return;
      refreshing = true;
      location.reload();
    });
    navigator.serviceWorker.register("sw.js").catch(() => { /* offline is a bonus, not a requirement */ });
  }
})();

export { progress };
