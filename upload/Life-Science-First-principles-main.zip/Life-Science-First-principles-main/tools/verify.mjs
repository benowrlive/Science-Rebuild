import { chromium } from "playwright";
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";

/* Repo-relative so this runs from a clone, in CI, on anyone's machine. */
const ROOT = new URL("..", import.meta.url).pathname.replace(/\/$/, "");
const SHOTS = join(ROOT, "shots");
const MIME = { ".html":"text/html", ".js":"text/javascript", ".css":"text/css",
  ".json":"application/json", ".webmanifest":"application/manifest+json",
  ".woff2":"font/woff2", ".svg":"image/svg+xml", ".png":"image/png" };

const server = createServer(async (req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p.endsWith("/")) p += "index.html";
  const f = join(ROOT, normalize(p));
  try {
    const body = await readFile(f);
    res.writeHead(200, { "content-type": MIME[extname(f)] ?? "application/octet-stream" });
    res.end(body);
  } catch { res.writeHead(404).end("nope"); }
});
mkdirSync(new URL("../shots", import.meta.url), { recursive: true });
await new Promise((r) => server.listen(8099, r));
const BASE = "http://localhost:8099/";

const results = [];
const check = (name, pass, detail = "") => { results.push({ name, pass, detail }); };

// CHROME_PATH lets a sandbox point at a preinstalled binary; without it,
// Playwright resolves its own browser as normal.
const browser = await chromium.launch(
  process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {});
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 2,
  acceptDownloads: true });   // the save-a-copy check downloads a real file
const page = await ctx.newPage();
/* ONE definition of "on screen", available to every page.evaluate in this file.

   getClientRects() was the D70 answer and it is not enough: Chrome hides a closed
   <details> with content-visibility, and its descendants still report boxes. Only
   checkVisibility() accounts for that. The rule stands — do not ask an element
   what it thinks it is doing — but the way to ask had to get sharper. (D73) */
await ctx.addInitScript(() => {
  window.shown = (n) => (n.checkVisibility
    ? n.checkVisibility({ contentVisibilityAuto: true, visibilityProperty: true })
    : n.getClientRects().length > 0);
});
const errors = [];
/* Two tests deliberately break the network — one severs it entirely, one blocks a
   single file to prove the shelf survives without it. A request that fails while
   the test is holding the network down is the test's own doing, not a defect. Only
   that message class, and only inside the window, so a real error still shows. */
let breakingNetwork = false;
const expectedOffline = (t) =>
  breakingNetwork && /Failed to fetch|Failed to load resource|NetworkError|net::ERR/.test(t);
page.on("console", (m) => {
  // One test throws on purpose to prove the loop survives it; its own log is
  // not a defect. Everything else is.
  if (m.type() === "error" && !/FP-BAD stopped/.test(m.text()) && !expectedOffline(m.text())) {
    errors.push(m.text());
  }
});
page.on("pageerror", (e) => { if (!expectedOffline(String(e))) errors.push(String(e)); });
/* "TypeError: Failed to fetch" names no resource, which makes it a riddle rather
   than a report. Record what actually failed, so the next one reads as a fact. */
const failedRequests = [];
page.on("requestfailed", (r) => failedRequests.push(
  `${new URL(r.url()).pathname} (${r.failure()?.errorText ?? "?"})`));

/* THE APP SAYS WHEN IT HAS FINISHED BOOTING; THE HARNESS SHOULD LISTEN. boot()
   sets [data-ready] on the body in its finally block — success path and failure
   path alike — and that is the only honest "I am done" this app has.

   domcontentloaded fires long before it. Three tests navigated on that signal and
   then immediately navigated again, which aborted the content/curriculum.json
   fetch still in flight; the app then correctly reported a curriculum it could not
   load, and the console-error audit counted the harness's own doing as a defect.
   It failed roughly one run in three, which is the worst kind of failing.

   Reproduced by holding curriculum.json for 200ms: 8 loads out of 8 errored on
   the old sequence, 0 out of 8 with this wait, and no aborted requests at all.
   Waiting for the flag the app already sets costs nothing and removes the race
   rather than filtering its symptom. (D75) */
const landed = async (url = BASE, waitUntil = "domcontentloaded") => {
  await page.goto(url, { waitUntil });
  await page.waitForSelector("body[data-ready]", { timeout: 8000 });
};

await page.goto(BASE, { waitUntil: "networkidle" });

/* 1. A cold start now says WHAT THIS IS before asking anything. It used to open
   on the reading-level picker, which offered four sentences about cells to a
   parent who had not been told what the thing was. Reported as "there is no
   intro, so the context is bland when the page opens", and it was right. (D72) */
check("cold start says what this is before asking anything",
  (await page.locator("main h1").textContent()).length > 20
  && await page.locator(".welcome-facts li").count() >= 3,
  await page.locator("main h1").textContent());
check("the front door names who owns it",
  /©/.test(await page.locator(".owner-line").textContent()),
  await page.locator(".owner-line").textContent());
await page.locator("main .next-btn").click();

/* Between the handover and the picker sits the child's opening. It is asserted
   properly further down; here the flow just has to walk through it, because a
   five-year-old's first screen is no longer a reading test. (D81) */
await page.waitForSelector(".intro-poke");
check("handing over shows the child's opening", true, "Poke it.");
await page.locator(".intro .next-btn").click();
await page.waitForSelector(".picker-card");

// then the level picker
check("and the opening leads on to the level picker",
  (await page.locator("#main h1").textContent()) === "Which one feels right?");
check("picker offers exactly 4 reading samples", await page.locator(".picker-card").count() === 4);

// touch target audit at each level, from the DOM not the token
const box = async (sel) => (await page.locator(sel).first().boundingBox());
const EXPECT = { 1: 76, 2: 60, 3: 48, 4: 44 };

// 2. choose level 2 -> atlas
await page.locator(".picker-card").nth(1).click();
await page.waitForSelector(".islands");
check("picking a level lands on the Atlas", (await page.locator("h1").textContent()) === "Atlas");
// Only worlds with playable content are drawn. Eighteen modules of "not yet
// written" read as abandoned rather than early.
/* Derived, never a literal. These were `=== 1` and `=== 5` when Cells was the
   only authored module, and both silently stopped meaning anything the moment a
   second module landed — they asserted a snapshot of the content rather than
   the rule the content has to obey. */
{
  const r = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    const satisfiable = (w) => w.requires.every((id) => {
      const m = c.worlds.flatMap((x) => x.modules).find((x) => x.id === id);
      return m && c.writtenCount(m.id) >= m.lessons;
    });
    return {
      drawn: c.playableWorlds().map((w) => w.id),
      coming: c.comingWorlds().map((w) => w.id),
      withContent: c.worlds.filter(c.worldHasContent).map((w) => w.id),
      badlyDrawn: c.playableWorlds().filter((w) => !c.worldHasContent(w) || !satisfiable(w)).map((w) => w.id),
    };
  });
  const islands = await page.locator(".island").count();
  const listed = await page.locator(".signpost-list li").count();
  check("the Atlas draws exactly the worlds that are playable",
    islands === r.drawn.length && r.drawn.length > 0, `${islands} islands, expected ${r.drawn.length}`);
  check("and names every other world honestly instead of hiding it",
    listed === r.coming.length && islands + listed === 6, `${listed} listed, ${islands} drawn`);
  // Authoring Change before Code produced a world with real lessons behind a
  // gate no amount of play could open. A door with no key is worse than no door.
  check("no world is drawn that has no content or no reachable path",
    r.badlyDrawn.length === 0, r.badlyDrawn.join(",") || "none");
}
// The dependency graph itself must be unchanged — the display was gated, the
// model was not.
{
  const graph = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    const s = await import("./js/state.js");
    return {
      total: c.worlds.reduce((n, w) => n + w.modules.length, 0),
      openNow: c.worlds.flatMap((w) => w.modules).filter((m) => c.isModuleUnlocked(m.id, s.progress)).length,
    };
  });
  check("all 25 modules still exist in the graph behind it",
    graph.total === 25 && graph.openNow === 1, JSON.stringify(graph));
}

// 3. unlock graph, cold save: only World 1 open, only its first module unlocked
const openNodes = await page.locator("a.node-hit").count();
check("exactly 1 module is open on a cold save", openNodes === 1, `${openNodes} open`);
check("the open module is What is Life?",
  (await page.locator("a.node-hit .node-title").textContent()) === "What is Life?");
/* A locked island is legitimate now that later worlds are authored — it is a
   preview and a goal. What is NOT legitimate is one whose stated prerequisite
   cannot be finished, which is the state the reachability rule exists to
   prevent. So the check moved from "no locked islands" to "every locked island
   names something a child can actually go and do". */
{
  const bad = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    return c.playableWorlds().flatMap((w) => w.requires).filter((id) => {
      const m = c.worlds.flatMap((x) => x.modules).find((x) => x.id === id);
      return !m || c.writtenCount(m.id) < m.lessons;
    });
  });
  check("every locked world names a prerequisite a child can actually finish",
    bad.length === 0, bad.join(",") || "none");
}
check("locks explain themselves rather than saying 'locked'",
  (await page.locator(".node--locked .node-status").first().textContent()).startsWith("Finish"));

// 4. continue card points at the next module
check("continue card targets the next module",
  (await page.locator(".continue").getAttribute("href")) === "#/m/what-is-life");

// 5. navigate into a module
await page.locator(".continue").click();
await page.waitForSelector(".module-head");
check("module route renders", (await page.locator("h1").textContent()) === "What is Life?");
check("focus moves to the new heading after routing",
  await page.evaluate(() => document.activeElement?.tagName === "H1"));
check("live region announces the route",
  (await page.locator("#live").textContent()) === "What is Life?");

// 6. keyboard: back link reachable and operable
await page.goto(BASE, { waitUntil: "networkidle" });
await page.waitForSelector(".islands");
await page.keyboard.press("Tab");
check("first tab stop on load is the skip link",
  await page.evaluate(() => document.activeElement?.className === "skip-link"),
  await page.evaluate(() => document.activeElement?.className ?? ""));
await page.locator(".continue").click();
await page.waitForSelector(".module-head");
check("route change still moves focus to the new heading",
  await page.evaluate(() => document.activeElement?.tagName === "H1"));
await page.goBack();
await page.waitForSelector(".islands");

// 7. locked modules are not keyboard-reachable (aria-disabled div, no tabindex)
check("locked modules are not focusable",
  await page.evaluate(() => ![...document.querySelectorAll(".node--locked .node-hit")]
    .some((n) => n.tabIndex >= 0)));

// 8. level scaling: measure a real rendered target at every level
for (const n of [1, 2, 3, 4]) {
  await page.evaluate((lv) => {
    const p = JSON.parse(localStorage.getItem("fp.progress"));
    p.prose = lv; p.content = lv;
    localStorage.setItem("fp.progress", JSON.stringify(p));
  }, n);
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".islands");
  // measure the element that actually sits ON the minimum, not a content-sized
  // card that would pass the assertion no matter what the token said
  const b = await box(".bar-link");
  check(`L${n}: minimum-size control >= ${EXPECT[n]}px`, b.height >= EXPECT[n] - 0.5,
    `measured ${b.height.toFixed(1)}px`);
  await page.screenshot({ path: join(SHOTS, `atlas-L${n}.png`), fullPage: false });
}

// 9. dark theme renders
await page.emulateMedia({ colorScheme: "dark" });
await page.reload({ waitUntil: "networkidle" });
await page.waitForSelector(".islands");
const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
check("dark scheme switches the ground", bg === "rgb(25, 22, 20)", bg);
await page.screenshot({ path: join(SHOTS, "atlas-dark.png") });
await page.emulateMedia({ colorScheme: "light" });

// 10. reduced motion does not remove causal animation hooks
await page.emulateMedia({ reducedMotion: "reduce" });
await page.reload({ waitUntil: "networkidle" });
const rm = await page.evaluate(() => {
  const probe = document.createElement("div");
  probe.style.transition = "opacity 400ms";
  document.body.append(probe);
  const normal = getComputedStyle(probe).transitionDuration;
  probe.dataset.motionRole = "teach";
  const teach = getComputedStyle(probe).transitionDuration;
  probe.remove();
  return { normal, teach };
});
check("reduced motion kills decorative transitions", rm.normal === "0.001s", rm.normal);
check("reduced motion PRESERVES causal (teach) animation", rm.teach === "0.4s", rm.teach);
await page.emulateMedia({ reducedMotion: "no-preference" });

// 11. progress drives the graph: complete What is Life?, Cells should open
await page.evaluate(() => {
  const p = JSON.parse(localStorage.getItem("fp.progress"));
  p.modules = { "what-is-life": { lessonsDone: 4 } };
  localStorage.setItem("fp.progress", JSON.stringify(p));
});
await page.reload({ waitUntil: "networkidle" });
await page.waitForSelector(".islands");
const titles = await page.locator("a.node-hit .node-title").allTextContents();
check("completing What is Life? opens Cells", titles.includes("Cells"), titles.join(", "));
{
  const expect = await page.evaluate(async () =>
    (await import("./js/curriculum.js")).playableWorlds().length);
  const islands = await page.locator(".island").count();
  check("finishing one module does not conjure worlds that have no content",
    islands === expect, `${islands} islands, expected ${expect}`);
}

// 12. offline: kill the network and reload
await page.goto(BASE, { waitUntil: "networkidle" });
/* Not just "a worker controls the page": a NEW worker may still be installing,
   and its precache addAll() would then hit the severed network and reject. Wait
   until nothing is installing or waiting, or the test cuts the network out from
   under its own service worker and fails intermittently on a slow machine. */
await page.waitForFunction(async () => {
  const reg = await navigator.serviceWorker?.getRegistration?.();
  return !!navigator.serviceWorker?.controller && !!reg && !reg.installing && !reg.waiting;
}, null, { timeout: 15000 }).catch(() => {});
await page.waitForTimeout(300);
breakingNetwork = true;
await ctx.setOffline(true);
try {
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForSelector(".islands", { timeout: 5000 });
  check("cold reload works with the network off", true);
} catch (e) {
  check("cold reload works with the network off", false, String(e).slice(0, 80));
}
await ctx.setOffline(false);
breakingNetwork = false;

/* 13. Real contrast audit: not token pairs, but every rendered text node
   against the background it actually composites onto. This is what catches a
   colour that passed in isolation and fails once it lands on a tinted card. */
async function auditContrast(label) {
  const bad = await page.evaluate(() => {
    const lin = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
    const lum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
    const rgb = (s) => (s.match(/[\d.]+/g) || []).map(Number);
    const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m); return (x + 0.05) / (y + 0.05); };
    const bgOf = (node) => {
      for (let n = node; n && n !== document.documentElement; n = n.parentElement) {
        const c = rgb(getComputedStyle(n).backgroundColor);
        if (c.length >= 3 && (c[3] ?? 1) > 0.95) return c.slice(0, 3);
      }
      return rgb(getComputedStyle(document.body).backgroundColor).slice(0, 3);
    };
    const out = [];
    for (const n of document.querySelectorAll("main *, .app-bar *")) {
      const text = [...n.childNodes].filter((c) => c.nodeType === 3 && c.textContent.trim()).map((c) => c.textContent.trim()).join("");
      if (!text) continue;
      const cs = getComputedStyle(n);
      if (cs.visibility === "hidden" || cs.display === "none") continue;
      const size = parseFloat(cs.fontSize), weight = Number(cs.fontWeight) || 400;
      const large = size >= 24 || (size >= 18.66 && weight >= 700);
      const need = large ? 3 : 4.5;
      const r = ratio(rgb(cs.color).slice(0, 3), bgOf(n));
      if (r < need) out.push({ text: text.slice(0, 42), r: +r.toFixed(2), need, cls: n.className });
    }
    return out;
  });
  check(`contrast: every rendered text node passes AA (${label})`, bad.length === 0,
    bad.slice(0, 3).map((b) => `"${b.text}" ${b.r}<${b.need}`).join(" | "));
}

for (const route of ["#/", "#/m/what-is-life", "#/me"]) {
  await page.goto(BASE + route, { waitUntil: "networkidle" });
  await page.waitForSelector("main h1");
  await auditContrast(`light ${route}`);
}
await page.emulateMedia({ colorScheme: "dark" });
for (const route of ["#/", "#/m/what-is-life", "#/me"]) {
  await page.goto(BASE + route, { waitUntil: "networkidle" });
  await page.waitForSelector("main h1");
  await auditContrast(`dark ${route}`);
}
await page.screenshot({ path: join(SHOTS, "me-dark.png") });
await page.emulateMedia({ colorScheme: "light" });

// 14. capture the remaining surfaces for review
await page.goto(BASE + "#/me", { waitUntil: "networkidle" });
await page.waitForSelector(".choices", { timeout: 8000 });
await page.screenshot({ path: join(SHOTS, "me.png"), fullPage: true });
await page.goto(BASE + "#/m/what-is-life", { waitUntil: "networkidle" });
await page.waitForSelector(".module-head");
await page.waitForFunction(() => !document.startViewTransition || !document.querySelector("::view-transition"), null, { timeout: 2000 }).catch(() => {});
await page.waitForTimeout(600);
await page.screenshot({ path: join(SHOTS, "module.png") });
await page.evaluate(() => localStorage.clear());
await page.goto(BASE, { waitUntil: "networkidle" });
await page.waitForSelector(".welcome-h");
await page.screenshot({ path: join(SHOTS, "welcome.png"), fullPage: true });
await page.locator("main .next-btn").click();       // the front door comes first now
await page.waitForSelector(".intro-poke");         // then the child's opening (D81)
await page.screenshot({ path: join(SHOTS, "intro.png") });
for (let i = 0; i < 5; i++) { await page.locator(".intro-poke").click(); await page.waitForTimeout(150); }
await page.waitForTimeout(600);
await page.screenshot({ path: join(SHOTS, "intro-divided.png") });
await page.locator(".intro .next-btn").click();
await page.waitForSelector(".picker");
await page.screenshot({ path: join(SHOTS, "picker.png") });

// 15. conditional children must vanish, not stringify
/* (the picker screenshot above cleared storage, so re-establish a level first)

   LAND ON A FRESH DOCUMENT BEFORE WRITING THE SAVE. The app persists on a 500 ms
   debounce, and the click that produced the picker left one pending — so writing
   storage underneath a live document is a race against that timer, and the timer
   wins often enough to matter. It bit the day the Me screen grew by one section
   and the screenshot before this took forty milliseconds longer.

   Navigating fires pagehide, which flushes, so by the time this write lands
   nothing is in flight behind it. openWith() has done this since D72; this was
   the last direct write that had not learned it. (D79) */
await landed();
await page.evaluate(() => localStorage.setItem("fp.progress",
  JSON.stringify({ version: 1, level: 2, xp: 0, modules: {}, concepts: {}, specimens: [], streak: { days: 0, last: null }, prefs: {} })));
await page.goto(BASE + "#/m/what-is-life", { waitUntil: "networkidle" });
await page.reload({ waitUntil: "networkidle" });   // state.js reads storage at boot
await page.waitForSelector(".module-head");
await page.waitForTimeout(500);
check("no stringified nulls or undefineds in the DOM",
  !/\b(null|undefined)\b/.test(await page.locator("main").innerText()),
  (await page.locator("main").innerText()).match(/\b(null|undefined)\b/)?.[0] ?? "");

/* ===================== phase 3: the design system ===================== */

/* 16. Elevation direction. A drop shadow must be DARKER than the surface it
   falls on, in BOTH themes. Deriving shadows from --ink (which inverts) painted
   a pale halo under every dark-mode card and destroyed the raised/flat
   affordance the whole visual style depends on. */
async function elevationDirection(label) {
  const bad = await page.evaluate(() => {
    const lin = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
    const lum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
    const nums = (s) => (s.match(/[\d.]+/g) || []).map(Number);
    const surfaceOf = (n) => {
      for (let e = n; e && e !== document.documentElement; e = e.parentElement) {
        const c = nums(getComputedStyle(e).backgroundColor);
        if (c.length >= 3 && (c[3] ?? 1) > 0.95) return c.slice(0, 3);
      }
      return nums(getComputedStyle(document.body).backgroundColor).slice(0, 3);
    };
    const out = [];
    for (const n of document.querySelectorAll("main *, .sg-bar *")) {
      const sh = getComputedStyle(n).boxShadow;
      if (!sh || sh === "none") continue;
      // first colour in the list is the outermost drop shadow
      const first = sh.split(/,(?![^(]*\))/)[0];
      if (first.includes("inset")) continue;
      const c = nums(first).slice(0, 3);
      if (c.length < 3) continue;
      if (lum(c) >= lum(surfaceOf(n))) out.push({ cls: String(n.className).slice(0, 40), sh: first.trim().slice(0, 40) });
    }
    return out;
  });
  check(`elevation: drop shadows are darker than their surface (${label})`, bad.length === 0,
    bad.slice(0, 2).map((b) => `${b.cls}: ${b.sh}`).join(" | "));
}

/* 17. Affordance rule: inside main, raised == touchable, both directions. */

/* Nothing in this suite could see text printed on top of other text. The review
   reminder had all three of its lines stacked in one grid cell — at every width,
   on the Atlas, the first screen a returning child sees — and contrast, affordance
   and visibility audits all passed it happily, because each element was on screen,
   readable and correctly coloured. They were simply in the same place. (D74)

   Reported by a user. Boxes that overlap by more than a few pixels in both axes
   are a layout fault; a couple of pixels is a descender or a rounded corner. */
async function overlapAudit(label) {
  const clashes = await page.evaluate(() => {
    const nodes = [...document.querySelectorAll("main h1, main h2, main h3, main p, main span, main a, main li")]
      .filter((n) => n.textContent.trim() && !n.closest(".sr-only") && window.shown(n)
        && ![...n.children].some((c) => c.textContent.trim()));   // leaf text only
    const out = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i].getBoundingClientRect(), b = nodes[j].getBoundingClientRect();
        const dy = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        const dx = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        if (dy > 4 && dx > 4) {
          out.push(`"${nodes[i].textContent.trim().slice(0, 24)}" over `
            + `"${nodes[j].textContent.trim().slice(0, 24)}"`);
        }
      }
    }
    return out;
  });
  check(`no text printed on top of other text (${label})`, clashes.length === 0,
    clashes.slice(0, 2).join(" | "));
}

async function affordanceRule(label) {
  const bad = await page.evaluate(() => {
    /* <summary> is natively focusable and activates its <details> — it is a
       control, and the rule simply had never met a raised one before the shelf.
       An affordance rule that does not know the platform's own controls will
       eventually call a real button a decoration. */
    const touchable = (n) => !!n.closest('a[href],button,label,summary,[tabindex]:not([tabindex="-1"])');
    const raised = (n) => {
      const sh = getComputedStyle(n).boxShadow;
      return sh && sh !== "none" && !/^inset/.test(sh);
    };
    const out = [];
    for (const n of document.querySelectorAll("main *")) {
      if (n.closest(".sg-box, .sg-seg, .sg-card")) continue;   // style-guide demo furniture
      if (raised(n) && !touchable(n)) out.push(`raised but not touchable: .${n.className}`);
    }
    // A disabled control SHOULD be flat — that is the affordance rule working,
    // not breaking it. Only live controls are required to be raised.
    for (const n of document.querySelectorAll("main a[href], main button")) {
      if (n.disabled || n.getAttribute("aria-disabled") === "true") continue;
      // a raised descendant counts: the label's box carries the depth
      if (!raised(n) && ![...n.querySelectorAll("*")].some(raised)) {
        out.push(`touchable but flat: .${n.className || n.tagName}`);
      }
    }
    return out;
  });
  check(`affordance: raised means touchable, both ways (${label})`, bad.length === 0, bad.slice(0, 2).join(" | "));
}

for (const scheme of ["light", "dark"]) {
  await page.emulateMedia({ colorScheme: scheme });
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForSelector(".islands");
  await elevationDirection(scheme);
  await affordanceRule(scheme);
}
await page.emulateMedia({ colorScheme: "light" });

/* 18. The style guide must be clean at every level in both themes — it is the
   drift detector, so a failure here is a failure of the system, not the page. */
for (const scheme of ["light", "dark"]) {
  await page.emulateMedia({ colorScheme: scheme });
  for (const lv of [1, 2, 3, 4]) {
    await page.goto(BASE + "styleguide.html", { waitUntil: "networkidle" });
    await page.evaluate((n) => { document.documentElement.dataset.level = String(n);
    document.documentElement.dataset.age = String(n); }, lv);
    await page.waitForTimeout(120);
    const fails = await page.locator(".sg-fail").count();
    check(`styleguide: no failing token pair (${scheme} L${lv})`, fails === 0, `${fails} failing`);
  }
}
await page.emulateMedia({ colorScheme: "light" });

/* 19. Type scale multiplies the user's root size rather than replacing it. */
{
  const cdp = await ctx.newCDPSession(page);
  await page.goto(BASE + "styleguide.html", { waitUntil: "networkidle" });
  const base16 = await page.evaluate(() => parseFloat(getComputedStyle(document.documentElement).fontSize));
  let scaled = null;
  try {
    await cdp.send("Page.setFontSizes", { fontSizes: { standard: 24, fixed: 24 } });
    await page.reload({ waitUntil: "networkidle" });
    scaled = await page.evaluate(() => parseFloat(getComputedStyle(document.documentElement).fontSize));
    await cdp.send("Page.setFontSizes", { fontSizes: { standard: 16, fixed: 16 } });
  } catch { /* protocol unavailable */ }
  if (scaled != null) {
    check("type scale multiplies the user's default font size, not replaces it",
      scaled > base16 * 1.3, `16px default -> ${base16}px, 24px default -> ${scaled}px`);
  } else {
    check("type scale is declared as a percentage of the user's default", true, "CDP unavailable; checked in CSS");
  }
  await page.reload({ waitUntil: "networkidle" });
}

/* 20. Level switching moves type AND spacing together from one multiplier. */
{
  await page.goto(BASE + "styleguide.html", { waitUntil: "networkidle" });
  const read = async (lv) => page.evaluate((n) => {
    document.documentElement.dataset.level = String(n);
    document.documentElement.dataset.age = String(n);
    const probe = document.createElement("div");
    probe.style.cssText = "width:var(--s-4);font-size:var(--fs-md)";
    document.body.append(probe);
    const r = { space: parseFloat(getComputedStyle(probe).width), font: parseFloat(getComputedStyle(probe).fontSize) };
    probe.remove();
    return r;
  }, lv);
  const l1 = await read(1), l4 = await read(4);
  check("one multiplier scales type and space together",
    l1.font > l4.font && l1.space > l4.space,
    `L1 ${l1.font}px/${l1.space}px vs L4 ${l4.font}px/${l4.space}px`);
}

/* 21a. The service worker must not shadow other real pages at this origin with
   the app shell — falling back to the shell for every navigation made
   styleguide.html serve index.html and look like a broken build. */
{
  await page.goto(BASE + "styleguide.html", { waitUntil: "networkidle" });
  check("service worker does not shadow other pages with the app shell",
    (await page.title()).startsWith("Design system"), await page.title());
}

/* 21b. The reduced-motion substitution actually swaps the controls. */
{
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto(BASE + "styleguide.html", { waitUntil: "networkidle" });
  await page.waitForSelector(".teach-play", { state: "attached" });
  const on = await page.evaluate(() => ({
    play: getComputedStyle(document.querySelector(".teach-play")).display,
    steps: getComputedStyle(document.querySelector(".teach-steps")).display,
  }));
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.reload({ waitUntil: "networkidle" });
  const off = await page.evaluate(() => ({
    play: getComputedStyle(document.querySelector(".teach-play")).display,
    steps: getComputedStyle(document.querySelector(".teach-steps")).display,
  }));
  check("reduced motion substitutes step-through for autoplay",
    on.play === "none" && on.steps !== "none" && off.play !== "none" && off.steps === "none",
    `reduce: play=${on.play} steps=${on.steps} | normal: play=${off.play} steps=${off.steps}`);
  await page.screenshot({ path: join(SHOTS, "styleguide.png"), fullPage: false });
}

/* 22. Icon set is sized in em, so it tracks its label at every level. */
{
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForSelector(".islands");
  const sizes = [];
  for (const lv of [1, 4]) {
    await page.evaluate((n) => { document.documentElement.dataset.level = String(n);
    document.documentElement.dataset.age = String(n); }, lv);
    await page.waitForTimeout(80);
    sizes.push((await page.locator(".node-mark .icon").first().boundingBox()).width);
  }
  check("icons scale with their level", sizes[0] > sizes[1], `L1 ${sizes[0].toFixed(1)}px vs L4 ${sizes[1].toFixed(1)}px`);
}

/* 23. Visible, not merely present. A page can render, pass every contrast
   check and still be invisible — this caught an opacity rule leaking from the
   app shell onto the style guide. */
async function visibilityAudit(url, label) {
  await page.goto(url, { waitUntil: "networkidle" });
  await page.waitForSelector("main h1", { state: "attached" });
  await page.waitForTimeout(250);
  const hidden = await page.evaluate(() => {
    const out = [];
    for (const n of document.querySelectorAll("main h1, main h2, main p, main li")) {
      if (!n.textContent.trim()) continue;
      const r = n.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      let o = 1;
      for (let e = n; e; e = e.parentElement) o *= parseFloat(getComputedStyle(e).opacity);
      if (o < 0.5) out.push(n.textContent.trim().slice(0, 40));
    }
    return out;
  });
  check(`content is actually visible, not just present (${label})`, hidden.length === 0,
    hidden.slice(0, 2).join(" | "));
}
/* The front door, explicitly. Every audit in this file names its screens, so a
   NEW screen is covered by nothing until somebody adds it — which is exactly how
   a cream-on-cream button got through: present, sized, shadowed, unreadable. The
   welcome screen only appears on a save with no level set, so it needs its own
   visit rather than riding along on "#/" like the others. (D72) */
{
  await landed();
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".welcome-h", { timeout: 8000 });
  await auditContrast("light welcome");
  await affordanceRule("welcome");
  await overlapAudit("welcome");
  const cta = await page.evaluate(() => {
    const b = document.querySelector("main .next-btn");
    const cs = getComputedStyle(b);
    return { label: b.textContent.trim(), bg: cs.backgroundColor, fg: cs.color,
             boxes: b.getClientRects().length };
  });
  check("the front door's only button is readable",
    cta.boxes > 0 && cta.label.length > 4 && cta.bg !== "rgba(0, 0, 0, 0)",
    JSON.stringify(cta));
  await page.emulateMedia({ colorScheme: "dark" });
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".welcome-h", { timeout: 8000 });
  await auditContrast("dark welcome");
  await page.emulateMedia({ colorScheme: "light" });
  // and it hands over to the level picker, once
  await page.reload({ waitUntil: "networkidle" });
  await page.locator("main .next-btn").click();
  await page.waitForTimeout(300);
  const handed = await page.evaluate(() => document.querySelector("main h1")?.textContent);
  check("it hands over to the child's opening, not to a reading test",
    handed === "Poke it.", handed);
  await page.reload({ waitUntil: "networkidle" });
  const again = await page.evaluate(() => document.querySelector("main h1")?.textContent);
  check("and a parent is never shown the front door twice", again === "Poke it.", again);

  /* THE OPENING. The first thing a child ever touches in this product, and the
     one screen that cannot use either level dial because it runs before both are
     set. What it must do is the thesis in one gesture: they act, it responds,
     and the word comes last. (D81) */
  {
    await page.waitForSelector(".intro-poke");
    const first = await page.evaluate(() => ({
      cells: document.querySelectorAll(".intro-cell").length,
      count: document.querySelector(".intro-count")?.textContent,
      named: document.querySelector(".intro-named")?.hidden,
      h1s: document.querySelectorAll("main h1").length,
    }));
    check("it opens on one cell and an instruction, not a name",
      first.cells === 1 && first.count === "1 cell" && first.named === true, JSON.stringify(first));
    check("and it is still exactly one top-level heading", first.h1s === 1, `${first.h1s}`);

    const sizes = [];
    for (const expect of [2, 4, 8, 16, 32]) {
      await page.locator(".intro-poke").click();
      await page.waitForTimeout(160);
      const r = await page.evaluate(() => ({
        n: document.querySelectorAll(".intro-cell").length,
        w: parseFloat(getComputedStyle(document.querySelector(".intro-cell")).width),
        say: document.querySelector(".intro-count")?.textContent,
      }));
      sizes.push(r.w);
      if (r.n !== expect) check(`poking doubles the cells (${expect})`, false, JSON.stringify(r));
    }
    check("every poke doubles the cells, 1 through 32", true, "2 4 8 16 32");
    /* Cleavage divides without the whole growing, so each cell really is smaller
       than its parent. A child watching sees that without being told it. */
    check("and each generation is smaller than the one before",
      sizes.every((w, i) => i === 0 || w < sizes[i - 1]), sizes.map((w) => Math.round(w)).join(" > "));

    const after = await page.evaluate(() => ({
      named: document.querySelector(".intro-named")?.hidden,
      name: document.querySelector(".intro-name")?.textContent,
      live: document.querySelector(".intro-count")?.getAttribute("aria-live"),
    }));
    check("the word arrives only after they have done the thing",
      after.named === false && after.name === "Dividing.", JSON.stringify(after));
    check("and the count is announced, not just drawn", after.live === "polite", after.live);

    /* One control, not two hundred and fifty-six. A keyboard user presses space
       once; they do not tab through every cell on screen. */
    const focusables = await page.evaluate(() =>
      document.querySelectorAll("main button, main a[href], main [tabindex]:not([tabindex='-1'])").length);
    check("the field is one control, however many cells are in it",
      focusables <= 3, `${focusables} focusable things on screen`);

    await page.locator(".intro-poke").focus();
    const beforeKey = await page.locator(".intro-cell").count();
    await page.keyboard.press("Enter");
    await page.waitForTimeout(200);
    check("and it divides from the keyboard as well as a finger",
      (await page.locator(".intro-cell").count()) === beforeKey * 2, "");

    await auditContrast("the opening");
    await affordanceRule("the opening");
    await overlapAudit("the opening");

    /* A child who does not want to play must never be trapped, so the way on is
       there from the first second — and once taken, the opening is done with. */
    await page.locator(".intro .next-btn").click();
    await page.waitForTimeout(300);
    check("the way onward is there from the first second, and leads to the picker",
      (await page.evaluate(() => document.querySelector("main h1")?.textContent)) === "Which one feels right?", "");
    await page.reload({ waitUntil: "networkidle" });
    check("and the opening never plays twice",
      (await page.evaluate(() => document.querySelector("main h1")?.textContent)) === "Which one feels right?", "");
  }
  /* Put the world back. This block clears storage to reach the front door, and
     leaving it cleared sent every later test to the front door too. A test
     restores what it disturbs. Written out longhand because the freshSave and
     openWith helpers are declared further down the file than this runs. */
  await landed();                          // flush any pending write before overwriting (D79)
  await page.evaluate(() => localStorage.setItem("fp.progress", JSON.stringify({
    version: 2, prose: 2, content: 2, xp: 0, modules: {}, concepts: {},
    specimens: [], ledger: [], recent: [], prefs: {},
  })));
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".islands");
}

await visibilityAudit(BASE, "app");
await visibilityAudit(BASE + "styleguide.html", "styleguide");
await page.screenshot({ path: join(SHOTS, "styleguide.png") });

/* ===================== phase 4: lesson parts ===================== */
const SG = BASE + "styleguide.html";
const boardState = () => page.evaluate(() =>
  Object.fromEntries(Object.entries(document.querySelector("fp-board").state).filter(([, v]) => v)));

/* 24. The three input paths must produce identical state. This is the whole
   promise of the tap-tap/drag/keyboard primitive: one state machine, not three
   implementations that drift. */
{
  // path A: tap the part, tap the slot
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-placeable");
  await page.locator('fp-placeable[data-id="nucleus"]').click();
  await page.locator('fp-slot[data-label="Control centre"]').click();
  const byTap = await boardState();

  // path B: keyboard only — focus the part, Enter, focus the slot, Enter
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-placeable");
  await page.locator('fp-placeable[data-id="nucleus"]').focus();
  await page.keyboard.press("Enter");
  await page.locator('fp-slot[data-label="Control centre"]').focus();
  await page.keyboard.press("Enter");
  const byKeyboard = await boardState();

  // path C: press and drag past the threshold, release over the slot
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-placeable");
  await page.locator('fp-placeable[data-id="nucleus"]').scrollIntoViewIfNeeded();
  const from = await page.locator('fp-placeable[data-id="nucleus"]').boundingBox();
  const to = await page.locator('fp-slot[data-label="Control centre"]').boundingBox();
  await page.mouse.move(from.x + from.width / 2, from.y + from.height / 2);
  await page.mouse.down();
  await page.mouse.move(to.x + to.width / 2, to.y + to.height / 2, { steps: 12 });
  await page.mouse.up();
  const byDrag = await boardState();

  const same = JSON.stringify(byTap) === JSON.stringify(byKeyboard)
            && JSON.stringify(byTap) === JSON.stringify(byDrag);
  check("placement: tap, keyboard and drag reach identical state", same,
    `tap ${JSON.stringify(byTap)} | kbd ${JSON.stringify(byKeyboard)} | drag ${JSON.stringify(byDrag)}`);
  check("placement: the tap path actually placed something",
    Object.keys(byTap).length === 1, JSON.stringify(byTap));
}

/* 25. A shaky tap must stay a tap: movement under the threshold cannot become
   a drag, or a five-year-old loses the piece every time. */
{
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-placeable");
  await page.locator('fp-placeable[data-id="mito"]').scrollIntoViewIfNeeded();
  const b = await page.locator('fp-placeable[data-id="mito"]').boundingBox();
  await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2);
  await page.mouse.down();
  await page.mouse.move(b.x + b.width / 2 + 4, b.y + b.height / 2 + 3, { steps: 3 });  // 5px
  await page.mouse.up();
  const held = await page.evaluate(() =>
    document.querySelector('fp-placeable[data-id="mito"]').dataset.state);
  check("placement: a 5px wobble stays a tap, not a drag", held === "held", `state=${held}`);
}

/* 26. Wrong slot refuses, says why, and leaves the piece in hand. */
{
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-placeable");
  await page.locator('fp-placeable[data-id="nucleus"]').click();
  // aria-disabled="true" makes Playwright refuse a normal click, which is the
  // point — the slot announces as unavailable but stays operable, so force it
  await page.locator('fp-slot[data-label="Power plant"]').click({ force: true });
  const after = await boardState();
  const said = await page.locator("fp-board [role=status]").textContent();
  check("placement: an invalid slot refuses and explains",
    Object.keys(after).length === 0 && /does not go in/.test(said), said.slice(0, 60));
  // and invalid slots stay focusable — dropping them from the tab order
  // mid-gesture strands the keyboard user inside their own action
  const focusable = await page.evaluate(() =>
    [...document.querySelectorAll("fp-slot")].every((s) => s.tabIndex >= 0));
  check("placement: invalid slots stay in the tab order", focusable);
}

/* 27. Every placement is announced. */
{
  const said = await page.evaluate(async () => {
    document.querySelector('fp-placeable[data-id="wall"]').click();
    document.querySelector('fp-slot[data-label="Outer edge"]').click();
    return document.querySelector("fp-board [role=status]").textContent;
  });
  check("placement: the live region announces the result",
    /Membrane placed in Outer edge/.test(said), said);
}

/* 27b. A wrong answer must be changeable, and one gesture must cause exactly
   one state transition.

   Reported by a user, and it had been shipping the whole time: a piece dropped
   in the wrong slot could not be taken out again. Tapping it did visibly
   nothing, no error appeared anywhere, and every existing placement test passed
   — because they all placed a piece into an empty slot and stopped there.

   Two defects compounded. `connectedCallback` fires on every insertion and this
   component works by MOVING elements between the tray and the slots, so each
   placement re-ran setup and added a second click handler; and a placed piece
   is a child of its slot, so one tap was also handled by the slot. Handler one
   took the piece out, handler two picked it up, the slot put it back.

   Counting calls per tap is the check rather than asserting an end state: an
   even number of duplicate handlers cancels out and looks like a no-op, an odd
   number looks correct. Only the count sees both. */
{
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-placeable");
  const tally = await page.evaluate(() => {
    const board = document.querySelector("fp-board");
    const piece = document.querySelector('fp-placeable[data-id="nucleus"]');
    const slot = document.querySelector('fp-slot[data-label="Control centre"]');
    const n = { pickUp: 0, place: 0, unplace: 0 };
    for (const m of Object.keys(n)) {                 // instance props shadow the prototype
      const orig = board[m].bind(board);
      board[m] = (...a) => { n[m]++; return orig(...a); };
    }
    piece.click(); slot.click();                      // place it
    const placing = { ...n };
    piece.click();                                    // now change the answer
    return {
      placing, after: { ...n },
      held: board.held === piece,
      slotNowEmpty: board.state["Control centre"] === null,
      label: slot.getAttribute("aria-label"),
    };
  });
  check("placement: one tap on a placed piece lifts it out, once",
    tally.after.pickUp === tally.placing.pickUp + 1
    && tally.after.place === tally.placing.place
    && tally.held && tally.slotNowEmpty, JSON.stringify(tally));

  // and it lands in the hand, so changing an answer is two taps rather than
  // three — then straight into a different slot, which is the boss case where
  // any part fits any slot and a misplacement is the child's to correct
  const moved = await page.evaluate(() => {
    document.querySelectorAll("fp-slot").forEach((s) => s.removeAttribute("data-accepts"));
    const board = document.querySelector("fp-board");
    document.querySelector('fp-placeable[data-id="nucleus"]').click();
    document.querySelector('fp-slot[data-label="Control centre"]').click();
    document.querySelector('fp-placeable[data-id="nucleus"]').click();
    document.querySelector('fp-slot[data-label="Power plant"]').click();
    return board.state;
  });
  check("placement: a piece moves from one slot to another",
    moved["Power plant"] === "nucleus" && moved["Control centre"] === null, JSON.stringify(moved));

  /* And the same defect one level down: `Placeable.connectedCallback` called
     super and then added its pointerdown listener unconditionally, so the guard
     protected the tap path and the drag path went on doubling. A drag has to be
     tested on an ALREADY-PLACED piece — the existing drag test moves a piece
     out of the tray on a fresh page, where there is only ever one listener. */
  {
    await page.goto(SG, { waitUntil: "networkidle" });
    await page.waitForSelector("fp-placeable");
    await page.evaluate(() => {
      document.querySelectorAll("fp-slot").forEach((s) => s.removeAttribute("data-accepts"));
      document.querySelector('fp-placeable[data-id="nucleus"]').click();
      document.querySelector('fp-slot[data-label="Control centre"]').click();
    });
    const piece = page.locator('fp-placeable[data-id="nucleus"]');
    await piece.scrollIntoViewIfNeeded();
    const from = await piece.boundingBox();
    const to = await page.locator('fp-slot[data-label="Outer edge"]').boundingBox();
    await page.mouse.move(from.x + from.width / 2, from.y + from.height / 2);
    await page.mouse.down();
    await page.mouse.move(to.x + to.width / 2, to.y + to.height / 2, { steps: 12 });
    await page.mouse.up();
    const after = await boardState();
    check("placement: a placed piece can be dragged to another slot",
      after["Outer edge"] === "nucleus" && !after["Control centre"], JSON.stringify(after));
  }

  /* The slot's accessible name says what it holds, so it has to be rewritten
     when that changes. It was set once at connect: every slot announced itself
     as empty for ever, however full the board looked. */
  check("placement: a filled slot announces what it holds", /holds Nucleus/.test(
    await page.evaluate(() => {
      const slot = document.querySelector('fp-slot[data-label="Control centre"]');
      const piece = document.querySelector('fp-placeable[data-id="nucleus"]');
      if (piece.placedIn !== slot) { piece.click(); slot.click(); }
      return slot.getAttribute("aria-label");
    })), "aria-label never updates after a placement");
}

/* 28. Slider: native semantics survive the wrapper, keyboard moves it. */
{
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-slider input");
  const before = await page.locator("fp-slider input").inputValue();
  await page.locator("fp-slider input").focus();
  await page.keyboard.press("ArrowRight");
  await page.keyboard.press("ArrowRight");
  const after = await page.locator("fp-slider input").inputValue();
  const readout = await page.locator(".slider-value").textContent();
  const valuetext = await page.locator("fp-slider input").getAttribute("aria-valuetext");
  check("slider: arrow keys move it and the readout follows",
    Number(after) === Number(before) + 2 && readout === `${after}°C` && valuetext === readout,
    `${before} -> ${after}, readout "${readout}"`);
  const box = await page.locator("fp-slider input").boundingBox();
  check("slider: the hit area meets the level touch minimum", box.height >= 60 - 0.5, `${box.height}px`);
}

/* 29. Predict: commits, pays before knowing the answer, echoes the child's
   own words back, and treats a wrong prediction as discovery not failure. */
{
  await page.goto(SG, { waitUntil: "networkidle" });
  await page.waitForSelector("fp-predict button");
  const paid = await page.evaluate(() => new Promise((res) => {
    document.addEventListener("fp:predict", (e) => res(e.detail.answer), { once: true });
    document.querySelectorAll(".predict-option")[1].click();   // "They slow down" — wrong
  }));
  check("predict: XP event fires on committing, before the outcome is known",
    paid === "They slow down", String(paid));

  await page.locator("#run-right").click();
  const text = await page.locator(".predict-result").textContent();
  const matched = await page.locator(".predict-result").getAttribute("data-matched");
  const border = await page.evaluate(() =>
    getComputedStyle(document.querySelector(".predict-result")).borderInlineStartColor);
  const discovery = await page.evaluate(() => {
    const probe = document.createElement("span");
    probe.style.color = "var(--w-discovery-line)";
    document.body.append(probe);
    const c = getComputedStyle(probe).color; probe.remove(); return c;
  });
  check("predict: the child's own words are echoed back beside the result",
    /You saidThey slow down/.test(text) && /It didThey speed up/.test(text), text.slice(0, 90));
  check("predict: a wrong prediction reads as discovery, not failure",
    matched === "false" && border === discovery, `matched=${matched} border=${border} discovery=${discovery}`);
}

/* 30. Disclosure is native <details>: no JS, works with find-in-page. */
{
  const closed = await page.locator(".reveal p").isVisible();
  await page.locator(".reveal summary").click();
  const open = await page.locator(".reveal p").isVisible();
  check("disclosure: native <details> opens without any component", !closed && open);
}

/* 31. Nothing in phase 4 broke the affordance or contrast rules. */
await affordanceRule("styleguide parts");
await auditContrast("styleguide with parts");
await page.screenshot({ path: join(SHOTS, "parts.png"), fullPage: false });

/* ===================== phase 5: the gamification engine ===================== */

const freshSave = ({ level, ...extra } = {}) => ({
  version: 2, prose: level ?? 2, content: level ?? 2,
  xp: 0, modules: {}, concepts: {}, specimens: [], ledger: [], recent: [],
  prefs: {}, ...extra,
});
const setSave = (save) => page.evaluate((s) => localStorage.setItem("fp.progress", JSON.stringify(s)), save);
const getSave = () => page.evaluate(() => JSON.parse(localStorage.getItem("fp.progress")));

/* state.js reads localStorage once at module init, so writing the save and then
   changing only the hash leaves the old in-memory progress in place. Always
   land on the origin, write, navigate, then reload. */
async function openWith(save, hash = "") {
  await landed();
  await setSave(save);
  await page.goto(BASE + hash, { waitUntil: "networkidle" });
  await page.reload({ waitUntil: "networkidle" });
}


/* Drive the real modules in the page context so the tests exercise shipped
   code, not a reimplementation of it. */
const engine = (fn, arg) => page.evaluate(async ([src, a]) => {
  const [reward, sched, state] = await Promise.all([
    import("./js/reward.js"), import("./js/scheduler.js"), import("./js/state.js"),
  ]);
  // eslint-disable-next-line no-new-func
  return new Function("reward", "sched", "state", "arg", `return (${src})(reward, sched, state, arg);`)(reward, sched, state, a);
}, [fn.toString(), arg]);

/* A bare goto is no longer enough to reach the Atlas: a save with no level set
   lands on the front door. openWith guarantees a level, which is what every test
   from here on assumes. (D72) */
await openWith(freshSave({ level: 2 }));
await page.waitForSelector(".islands");

/* 32. The economy refuses to pay for the things it must never pay for. */
{
  const refusals = await engine((reward) => {
    const out = {};
    for (const bad of ["time", "watch", "streak", "login", "correctPredict", "vibes"]) {
      try { reward.awardXp(bad); out[bad] = "PAID"; }
      catch (e) { out[bad] = e.message; }
    }
    return out;
  });
  const allRefused = Object.values(refusals).every((v) => v !== "PAID");
  check("XP refuses time, watching, streaks, logins and unknown reasons", allRefused,
    Object.entries(refusals).filter(([, v]) => v === "PAID").map(([k]) => k).join(", "));
  check("the refusal explains itself rather than just throwing",
    /produces idling/.test(refusals.time) && /passivity/.test(refusals.watch), refusals.time);
}

/* 33. A wrong prediction pays exactly the same as a right one. That is the
   whole reason prediction works as a mechanism. */
{
  const r = await engine((reward, sched, state) => {
    state.reset();
    const first = reward.awardXp("predict");
    const second = reward.awardXp("predict");
    return { first, second, xp: state.progress.xp };
  });
  check("prediction pays the same regardless of correctness",
    r.first === r.second && r.first === 5 && r.xp === 10, JSON.stringify(r));
}

/* 34. Retrieval pays most; a missed attempt still pays a little, because the
   testing effect works on failed retrieval when feedback follows — but far too
   little to farm. */
{
  const r = await engine((reward) => ({
    hit: reward.RATES.retrievalHit, miss: reward.RATES.retrievalMiss,
    predict: reward.RATES.predict, complete: reward.RATES.lessonComplete,
  }));
  check("retrieval is the best-paid behaviour in the economy",
    r.hit > r.complete && r.hit > r.predict && r.miss > 0 && r.miss < r.hit / 3,
    JSON.stringify(r));
}

/* 35. The interval ladder actually schedules where it says it does. */
{
  const r = await engine((reward, sched, state) => {
    state.reset();
    const DAY = 864e5, t0 = 1700000000000;
    sched.seed("membrane", t0);
    const after = [];
    let now = t0;
    for (let i = 0; i < 5; i++) {
      const c = sched.review("membrane", sched.GRADE.got, now);
      after.push(Math.round((c.due - now) / DAY));
      now = c.due;
    }
    // now miss it: back to tomorrow, ease drops, history kept
    const lapsed = sched.review("membrane", sched.GRADE.missed, now);
    return { after, lapseDays: Math.round((lapsed.due - now) / DAY),
             lapses: lapsed.lapses, reps: lapsed.reps, ease: lapsed.ease };
  });
  check("the interval ladder climbs 1, 3, 7, 16, 35 days",
    JSON.stringify(r.after) === JSON.stringify([3, 7, 16, 35, 35]), JSON.stringify(r.after));
  check("a miss returns the concept to tomorrow but keeps its history",
    r.lapseDays === 1 && r.lapses === 1 && r.reps === 6 && r.ease < 1,
    `due in ${r.lapseDays}d, lapses ${r.lapses}, reps ${r.reps}, ease ${r.ease.toFixed(2)}`);
}

/* 36. A child back after a month meets a pile they can clear, and the UI says
   how many were held back rather than silently truncating. */
{
  const r = await engine((reward, sched, state) => {
    state.reset();
    const t0 = 1700000000000;
    for (let i = 0; i < 12; i++) sched.seed(`c${i}`, t0);
    const later = t0 + 60 * 864e5;
    return { due: sched.due(later).length, total: sched.dueCount(later), cap: sched.SESSION_CAP };
  });
  check("the due queue is capped at 5 with 12 waiting",
    r.due === 5 && r.total === 12 && r.cap === 5, JSON.stringify(r));
}

/* 37. Badges need survival over weeks, not completion. */
{
  const r = await engine((reward, sched, state) => {
    state.reset();
    // finish an entire module: no badge should appear
    for (let i = 0; i < 5; i++) reward.completeLesson("cells", i, {});
    const afterCompleting = reward.earnedBadges(state.progress).map((b) => b.id);
    // now actually remember one thing across the ladder
    const t0 = 1700000000000; let now = t0;
    sched.seed("membrane", t0);
    for (let i = 0; i < 3; i++) { const c = sched.review("membrane", sched.GRADE.got, now); now = c.due; }
    const afterRemembering = reward.earnedBadges(state.progress).map((b) => b.id);
    return { afterCompleting, afterRemembering, xp: state.progress.xp };
  });
  check("finishing a whole module earns no badge",
    r.afterCompleting.length === 0, r.afterCompleting.join(", "));
  check("remembering something a week later does earn one",
    r.afterRemembering.includes("sticks"), r.afterRemembering.join(", "));
}

/* 38. Specimens are an inventory: collected once, and they say what they unlock. */
{
  const r = await engine((reward, sched, state) => {
    state.reset();
    const first = reward.collect("ribosome");
    const again = reward.collect("ribosome");
    return { first, again, has: reward.hasSpecimen("ribosome"), n: state.progress.specimens.length };
  });
  check("a specimen collects once and stays collected",
    r.first === true && r.again === false && r.has && r.n === 1, JSON.stringify(r));
}

/* 39. The streak and the XP counter are gone from the UI on purpose: built
   carefully, read by nothing, shown to no measured benefit. What must NOT be
   gone is the ledger, because badges are derived from it. */
{
  const r = await engine((reward, sched, state) => {
    state.reset();
    reward.awardXp("predict");
    reward.awardXp("retrievalHit");
    return { ledger: state.progress.ledger.length, streak: "streak" in state.progress };
  });
  check("the XP ledger survives so badges keep their evidence",
    r.ledger === 2 && r.streak === false, JSON.stringify(r));
}

/* 40. The Atlas puts due reviews above new material and reports the true
   backlog rather than silently showing only the capped five. */
{
  // Seed nine overdue concepts on a *clean* page. Writing localStorage behind
  // the app's back only works if the running page has no pending debounced
  // write, or its pagehide flush overwrites what the test just wrote.
  const overdue = {};
  for (let i = 0; i < 9; i++) overdue[`c${i}`] = { step: 0, ease: 1, reps: 1, lapses: 0, due: Date.now() - 864e5, lastGrade: 1 };
  await openWith(freshSave({ level: 2, concepts: overdue }));
  await page.waitForSelector(".islands");
  const call = await page.locator(".review-call").textContent();
  const order = await page.evaluate(() => {
    const kids = [...document.querySelector("main").children].map((n) => String(n.className));
    return kids.findIndex((c) => c.startsWith("review-call")) < kids.findIndex((c) => c.startsWith("continue"));
  });
  check("the Atlas shows the review call above the next lesson", order, "");
  check("the review call reports the real backlog, not just the capped five",
    /9 are due/.test(call) && /5 at a time/.test(call), call.replace(/\s+/g, " ").slice(0, 90));
}

/* 41. Me renders badges and the specimen inventory, and the inventory is
   visibly an inventory — every specimen says what it unlocks. */
{
  await openWith(freshSave({ level: 2 }), "#/me");
  await page.waitForSelector(".badges");
  check("Me shows no XP number and no streak",
    !/\bXP\b|streak/i.test(await page.locator(".stats").innerText()),
    await page.locator(".stats").innerText().then((t) => t.replace(/\n/g, " ")));
  check("Me lists every badge with its real criterion",
    (await page.locator(".badge").count()) === 5, "");
  // Counted from the curriculum, not hard-coded: a literal here silently
  // stopped meaning anything as soon as the spine landed.
  const specimenTotal = await page.evaluate(async () =>
    (await import("./js/curriculum.js")).allSpecimens().length);
  check("Me shows the specimen collection including uncollected slots",
    (await page.locator(".specimen").count()) === specimenTotal && specimenTotal > 100,
    `${specimenTotal} slots`);
  await openWith(freshSave({ level: 2, specimens: ["ribosome"] }), "#/me");
  await page.waitForSelector(".specimen--got");
  const unlocks = await page.locator(".specimen--got .specimen-unlocks").textContent();
  check("a collected specimen states what it lets you build",
    /Build proteins in World 2/.test(unlocks), unlocks);
  await page.screenshot({ path: join(SHOTS, "me-phase5.png"), fullPage: true });
}

/* 42. No regressions in the rules that hold the whole design together. */
await affordanceRule("phase 5 Me");
await auditContrast("phase 5 Me");
await overlapAudit("Me");
await page.goto(BASE, { waitUntil: "networkidle" });
await page.waitForSelector(".islands");
await affordanceRule("phase 5 Atlas");
await auditContrast("phase 5 Atlas");
await overlapAudit("Atlas");

/* ===================== phase 6: the learning engine ===================== */

/* Walk a lesson, satisfying whatever gate each stage type has. */
async function stepLesson(maxSteps = 16, stopAt = null) {
  const seen = [], labels = [];
  for (let i = 0; i < maxSteps; i++) {
    if (await page.locator(".stage--done").count()) break;
    if (!(await page.locator(".stage").count())) break;
    const t = await page.locator(".stage").getAttribute("data-type");
    seen.push(t);
    if (t === "slider") labels.push(await page.locator(".slider-label").textContent());
    if (t === stopAt) break;
    if (t === "predict") await page.locator(".predict-option").first().click();
    if (t === "check") await page.locator(".quiz-option").first().click();
    if (t === "slider") { await page.locator("fp-slider input").focus(); await page.keyboard.press("End"); }
    if (t === "sim") { await page.waitForSelector(".sim-canvas"); await page.locator(".stage-actions button").click(); }
    /* A WALKER THAT STOPS AT A BUILD STAGE CANNOT TEST ANYTHING AFTER ONE, and
       52 lessons of 110 have one. It stopped silently — the Next button is
       disabled, the loop breaks, and the caller gets a short path that looks
       like a complete one. Assembled by tap-then-tap using each slot's own
       answer, because a boss slot is unconstrained and carries no `accepts`. */
    if (t === "build") {
      const slots = await page.locator("fp-slot").count();
      for (let k = 0; k < slots; k++) {
        const want = await page.locator("fp-slot").nth(k).getAttribute("data-correct");
        await page.locator(`fp-placeable[data-id="${want}"]`).click();
        await page.locator("fp-slot").nth(k).click();
        await page.waitForTimeout(30);
      }
    }
    const next = page.locator(".next-btn");
    if (!(await next.count()) || await next.isDisabled()) break;
    await next.click();
    await page.waitForTimeout(70);
  }
  return { seen, labels };
}

/* 43. Every level gets a complete path, and the two tracks really differ.
   This is the pedagogy fork, and the reason stage-level filtering exists. */
{
  const per = {};
  for (const lv of [1, 2, 3, 4]) {
    await openWith(freshSave({ level: lv }), "#/l/cells/0");
    await page.waitForSelector(".stage");
    per[lv] = await stepLesson();
  }
  check("every level gets a complete path through the lesson",
    [1, 2, 3, 4].every((lv) => ["hook", "predict", "slider", "name", "check"].every((t) => per[lv].seen.includes(t))),
    [1, 2, 3, 4].map((lv) => `L${lv}:${per[lv].seen.join(">")}`).join("  "));
  check("L1/L2 get the guided exploration, L3/L4 the open one",
    per[1].labels[0] === "How close are we?" && per[4].labels[0] === "Powers of ten",
    `L1 "${per[1].labels[0]}" vs L4 "${per[4].labels[0]}"`);
  check("no child ever sees both tracks",
    [1, 2, 3, 4].every((lv) => per[lv].seen.filter((t) => t === "slider").length === 1),
    [1, 2, 3, 4].map((lv) => per[lv].seen.filter((t) => t === "slider").length).join(","));
}

/* 43b. THE MARKER IS THE NAMING, so what is tested is that the right run of
   characters is marked and that nothing was lost cutting the sentence up —
   not what the highlight looks like. A renderer that silently marked nothing
   would still have drawn a correct-looking page, which is the whole reason
   this is a test rather than a screenshot. (D87) */
{
  const lesson = JSON.parse(readFileSync(join(ROOT, "content/cells/01-city-in-a-speck.json"), "utf8"));
  const naming = lesson.stages.find((s) => s.type === "name");

  const at = async (lv, extra = {}) => {
    await openWith(freshSave({ level: lv, ...extra }), "#/l/cells/0");
    await page.waitForSelector(".stage");
    await stepLesson(16, "name");
    return {
      sentence: await page.locator(".stage-name").textContent(),
      marks: await page.locator(".stage-name mark.term").count(),
      marked: await page.locator(".stage-name mark.term").first().textContent().catch(() => null),
      known: await page.locator(".stage-name mark.term[data-known]").count(),
      boxed: await page.locator(".stage-term").first().textContent().catch(() => null),
    };
  };

  const seen = {};
  for (const lv of [1, 4]) seen[lv] = await at(lv);

  check("the naming marks the term the content declares, once",
    [1, 4].every((lv) => seen[lv].marks === 1 && seen[lv].marked === naming.term[lv - 1]),
    [1, 4].map((lv) => `L${lv} ${seen[lv].marks}x "${seen[lv].marked}"`).join("  "));

  /* Cutting a sentence into three text nodes is exactly the operation that
     loses a character at a boundary, and it would lose it silently. */
  check("cutting the sentence up loses nothing",
    [1, 4].every((lv) => seen[lv].sentence === naming.t[lv - 1]),
    [1, 4].map((lv) => (seen[lv].sentence === naming.t[lv - 1] ? `L${lv} ok` : `L${lv} "${seen[lv].sentence}"`)).join("  "));

  check("the boxed keyword carries the same word as the marker",
    [1, 4].every((lv) => seen[lv].boxed === seen[lv].marked),
    [1, 4].map((lv) => `L${lv} box "${seen[lv].boxed}"`).join("  "));

  /* Met already: the sweep must not replay a moment that has passed. The state
     is read from the retrieval schedule, so this seeds the schedule rather than
     anything the lesson screen owns. */
  const fresh = await at(2);
  const met = await at(2, { concepts: { [naming.concept]: { step: 2, ease: 1, reps: 3, lapses: 0, due: Date.now() + 8.64e7, lastGrade: 1 } } });
  check("a concept already met arrives already marked, and a new one does not",
    met.known === 1 && fresh.known === 0, `met ${met.known}, fresh ${fresh.known}`);
}

/* 43c. A LEVEL THAT WITHHOLDS THE NAME MUST RENDER PLAIN PROSE. "Blood goes
   round in a loop" names nothing, and the correct rendering of that is a
   sentence with no highlight — not a highlight over an arbitrary phrase. */
{
  const lesson = JSON.parse(readFileSync(join(ROOT, "content/what-is-life/02-seven-rules-and-their-exceptions.json"), "utf8"));
  const naming = lesson.stages.find((s) => s.type === "name");
  await openWith(freshSave({ level: 1, modules: { "what-is-life": { lessonsDone: 1 } } }), "#/l/what-is-life/1");
  await page.waitForSelector(".stage");
  await stepLesson(16, "name");
  const marks = await page.locator(".stage-name mark.term").count();
  const boxes = await page.locator(".stage-term").count();
  const sentence = await page.locator(".stage-name").textContent();
  check("a level with no name given renders the sentence plain, and no empty box",
    naming.term[0] === "" && marks === 0 && boxes === 0 && sentence === naming.t[0],
    `term "${naming.term[0]}", ${marks} marks, ${boxes} boxes`);
}

/* 44. The same stage reads at the child's level. */
{
  /* Measures the WHOLE hook, not the headline. The headline is deliberately one
     sentence now, so its length says nothing about the level — this test failed
     the moment the split landed, having bound itself to an element rather than to
     the claim. The claim is that the prose differs by level, and the corpus-wide
     version of it is asserted exactly in the build, where the content is. (D72) */
  const read = async (lv) => {
    await openWith(freshSave({ level: lv }), "#/l/cells/0");
    await page.waitForSelector(".stage-hook");
    return page.evaluate(() => [...document.querySelectorAll(".stage-hook, .stage-hook ~ .stage-lead")]
      .map((n) => n.textContent).join(" ").trim());
  };
  const l1 = await read(1), l4 = await read(4);
  const w = (t) => t.split(/\s+/).length;
  check("the same stage reads differently at five and at sixteen",
    l1 !== l4 && w(l1) <= w(l4), `L1 ${w(l1)}w vs L4 ${w(l4)}w`);
}

/* 45. A wrong answer shows the mechanism, and carries a mark not just a hue. */
{
  await openWith(freshSave({ level: 2 }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  await stepLesson(12, "check");
  await page.locator(".quiz-option").nth(2).click();
  const why = await page.locator(".quiz-why").textContent();
  const marks = await page.evaluate(() =>
    [...document.querySelectorAll(".quiz-option")].map((b) => b.dataset.mark ?? ""));
  check("a wrong answer explains the mechanism rather than scoring you",
    why.length > 40 && /full stop|micrometre/i.test(why), why.slice(0, 60));
  check("right and wrong options carry a mark, not only a colour",
    marks.includes("correct") && marks.includes("chosen"), marks.join("|"));
  const xp = (await getSave()).xp;
  check("a missed retrieval still pays, but far less than a hit", xp > 0 && xp < 20, `xp ${xp}`);
}

/* 46. Finishing pays, banks the specimen, and seeds the spacing schedule. */
{
  await openWith(freshSave({ level: 2 }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  await stepLesson(16);
  const save = await getSave();
  check("finishing the lesson marks it done", save.modules?.cells?.lessonsDone === 1, JSON.stringify(save.modules));
  check("finishing banks the specimen", save.specimens.includes("scale-lens"), save.specimens.join(","));
  check("finishing seeds both concepts into the retrieval schedule",
    Object.keys(save.concepts).sort().join(",") === "cell-is-a-system,cell-scale",
    Object.keys(save.concepts).join(","));
  check("the concepts are scheduled for tomorrow, not for now",
    Object.values(save.concepts).every((c) => c.due > Date.now() + 20 * 36e5), "");
  await page.screenshot({ path: join(SHOTS, "lesson-done.png") });
}

/* 47. The review flow grades back into the ladder. */
{
  const past = Date.now() - 864e5;
  await openWith(freshSave({
    level: 2,
    concepts: {
      "cell-scale": { step: 0, ease: 1, reps: 1, lapses: 0, due: past, lastGrade: 1 },
      "cell-is-a-system": { step: 0, ease: 1, reps: 1, lapses: 0, due: past, lastGrade: 1 },
    },
  }), "#/review");
  await page.waitForSelector("fp-quiz");
  check("the review flow only offers concepts that are actually due",
    (await page.locator(".stage-kicker").textContent()).includes("1 of 2"),
    await page.locator(".stage-kicker").textContent());

  await page.locator(".quiz-option").first().click();
  await page.locator(".next-btn").click();
  await page.waitForTimeout(90);
  await page.locator(".quiz-option").nth(1).click();
  await page.locator(".next-btn").click();
  await page.waitForSelector(".stage--done");

  const save = await getSave();
  const hit = Object.values(save.concepts).find((c) => c.lapses === 0);
  const miss = Object.values(save.concepts).find((c) => c.lapses === 1);
  const days = (c) => Math.round((c.due - Date.now()) / 864e5);
  check("a correct review pushes the concept further out", hit && days(hit) >= 3,
    hit ? `${days(hit)} days` : JSON.stringify(save.concepts));
  check("a missed review brings it back tomorrow and drops ease",
    miss && days(miss) === 1 && miss.ease < 1,
    miss ? `${days(miss)}d, ease ${miss.ease.toFixed(2)}` : JSON.stringify(save.concepts));
  check("the review flow pays for both hits and misses", save.xp >= 19, `xp ${save.xp}`);
}

/* 48. An empty queue says why rather than inventing work. */
{
  await openWith(freshSave({ level: 2 }), "#/review");
  await page.waitForSelector("main h1");
  const body = await page.locator("main").textContent();
  check("an empty queue explains why rather than manufacturing a quiz",
    /Nothing due/.test(body) && /gap/.test(body), body.replace(/\s+/g, " ").slice(0, 70));
}

/* 49. The module screen is honest about what is written. */
{
  await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 } } }), "#/m/cells");
  await page.waitForSelector(".lessons");
  const links = await page.locator("a.lesson-hit").count();
  const flat = await page.locator("div.lesson-hit").count();
  check("every lesson of the flagship module is now a real link",
    links === 5 && flat === 0, `${links} links, ${flat} flat`);
  check("and the 'not written yet' notice disappears once they all are",
    (await page.locator(".notice--soft").count()) === 0, "");
  /* A module that is still unwritten must still say so. Which module that IS
     changes every time one gets authored, so it is looked up rather than named
     — this test pointed at Biomolecules and broke the moment Biomolecules was
     written, which is the third literal in this file to age out that way. */
  const blank = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    const m = c.worlds.flatMap((w) => w.modules).find((x) => c.writtenCount(x.id) === 0);
    return m ? { id: m.id, lessons: m.lessons } : null;
  });
  if (!blank) {
    check("an unwritten module is still honest about it", true, "every module is authored — nothing left to warn about");
  } else {
    await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 5 } } }), `#/m/${blank.id}`);
    await page.waitForSelector(".lessons");
    const note = await page.locator(".notice--soft").textContent();
    check("an unwritten module is still honest about it",
      new RegExp(`0 of ${blank.lessons} lessons are written`).test(note), `${blank.id}: ${note}`);
  }
}

/* 50. A child on the Atlas never downloads the lesson runner. */
{
  const requested = [];
  const listener = (r) => requested.push(new URL(r.url()).pathname);
  page.on("request", listener);
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.waitForSelector(".islands");
  const leaked = requested.some((u) => /\/js\/lesson\//.test(u));
  page.off("request", listener);
  check("the Atlas never downloads the lesson runner", !leaked,
    requested.filter((u) => /lesson/.test(u)).join(", "));
}

/* 51. The design rules still hold on the new surfaces. */
{
  await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 } } }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  await affordanceRule("lesson");
  await auditContrast("lesson");
  await overlapAudit("lesson");
}

/* ===================== phase 7: simulations ===================== */

/** Walk to the sim stage of lesson 2 at a given level. */
async function openSim(lv) {
  await openWith(freshSave({ level: lv, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 1 } } }), "#/l/cells/1");
  await page.waitForSelector(".stage");
  for (let i = 0; i < 8; i++) {
    const t = await page.locator(".stage").getAttribute("data-type");
    if (t === "sim") break;
    if (t === "predict") await page.locator(".predict-option").first().click();
    await page.waitForTimeout(50);
    await page.locator(".next-btn").click();
    await page.waitForTimeout(70);
  }
  await page.waitForSelector(".sim-canvas");
  await page.waitForTimeout(400);
}

/* 52. The simulation narrates itself. Blueprint 10: a sim that cannot say what
   it is doing is unusable without sight, and the base class refuses to run
   without describe(). */
{
  await openSim(2);
  const live = await page.locator(".sim-live").textContent();
  const alt = await page.locator(".sim-canvas").getAttribute("aria-label");
  check("the simulation describes its own state in a sentence",
    /Holes set to \d/.test(live) && /inside/.test(live), live.slice(0, 80));
  check("the canvas carries that description as its text alternative",
    alt === live && (await page.locator(".sim-canvas").getAttribute("role")) === "img", (alt ?? "").slice(0, 40));
  const contract = await page.evaluate(async () => {
    const { Sim } = await import("./js/sims/base.js");
    // Custom-element constructors cannot be called directly, so exercise the
    // contract the way a half-finished subclass would hit it.
    try { Sim.prototype.describe.call({ tagName: "FP-BAD" }); return "no error"; }
    catch (e) { return e.message; }
  });
  check("the base class refuses a simulation that cannot describe itself",
    /describe\(\) not implemented/.test(contract), contract.slice(0, 60));
}

/* 53. Diffusion is real, not scripted. Nothing in the file knows which way is
   "in": net movement has to fall out of an unbiased random walk plus a
   concentration difference. So it must equalise, and it must not overshoot. */
{
  const result = await page.evaluate(async () => {
    const sim = document.querySelector("fp-membrane");
    // A physics claim needs a sample big enough to make it. With ~50 particles
    // one instant carries sigma ~= 0.07, and a random walk decorrelates slowly
    // enough that time-averaging alone does not rescue it. Raise N for the
    // measurement rather than loosening the threshold until it passes.
    sim.params.per = 200;
    sim.setup();
    sim.pore = 9;                       // holes wide enough for everything
    const inside = () => sim.parts.filter((p) => p.x > 0.5).length / sim.parts.length;
    const start = inside();
    // Five small pores make this slow on purpose — that IS the mechanism.
    for (let i = 0; i < 12000; i++) sim.step(1 / 60);
    // With ~50 particles a single instant carries a standard deviation of about
    // 0.07, so a snapshot cannot tell equilibrium from noise. Average over time.
    const mean = (n) => {
      let acc = 0;
      for (let i = 0; i < n; i++) { sim.step(1 / 60); acc += inside(); }
      return acc / n;
    };
    const r = { start, first: mean(3000), second: mean(3000), n: sim.parts.length };
    sim.params.per = 12;                // put it back for the rest of the suite
    sim.setup();
    return r;
  });
  check("with the holes open, concentrations even out on their own",
    Math.abs(result.second - 0.5) < 0.08,
    `${result.n} molecules: started ${result.start.toFixed(2)} inside, settled at ${result.second.toFixed(2)}`);
  check("and then hold there — diffusion reaches equilibrium, it does not overshoot",
    Math.abs(result.second - result.first) < 0.05,
    `${result.start.toFixed(2)} -> ${result.first.toFixed(2)} -> ${result.second.toFixed(2)}`);
}

/* 54. Size is the only thing that decides passage. Shut the pores and the big
   molecules must stay put while the small ones still move. */
{
  const r = await page.evaluate(async () => {
    const sim = document.querySelector("fp-membrane");
    sim.setup();
    sim.pore = 2;                       // admits water (1) but not poison (6)
    const side = (id) => sim.parts.filter((p) => p.kind.id === id && p.x > 0.5).length;
    const poisonBefore = side("poison");
    for (let i = 0; i < 6000; i++) sim.step(1 / 60);
    return { poisonBefore, poisonAfter: side("poison"), waterIn: side("water"),
             waterTotal: sim.parts.filter((p) => p.kind.id === "water").length };
  });
  check("a pore smaller than a molecule blocks it completely",
    r.poisonAfter === r.poisonBefore, `poison inside ${r.poisonBefore} -> ${r.poisonAfter}`);
  check("while smaller molecules still cross freely",
    r.waterIn > 0 && r.waterIn < r.waterTotal, `${r.waterIn} of ${r.waterTotal} water inside`);
}

/* 55. The frame budget from blueprint 13: under 8ms, with headroom to 16. */
{
  const ms = await page.evaluate(() => {
    const sim = document.querySelector("fp-membrane");
    const t0 = performance.now();
    for (let f = 0; f < 60; f++) { sim.step(1 / 60); sim.render(); }
    return (performance.now() - t0) / 60;
  });
  check("a simulation frame costs less than the 8ms budget", ms < 8, `${ms.toFixed(2)}ms per frame`);
}

/* 56. One loop for all sims, and it stops when nobody is watching. */
{
  const r = await page.evaluate(async () => {
    const { _running } = await import("./js/sims/base.js");
    const sim = document.querySelector("fp-membrane");
    // Earlier tests drive this sim past its goal. Meeting a goal no longer
    // stops a sim (D46), but clear the flag anyway so this measures membership
    // rather than whatever the previous test left behind.
    sim.met = false;
    sim.play();
    const playing = _running.size;
    sim.pause();
    return { playing, paused: _running.size };
  });
  check("sims register with one shared loop and leave it when paused",
    r.playing === 1 && r.paused === 0, JSON.stringify(r));
}

/* 57. Reduced motion substitutes rather than removes — the whole argument of
   blueprint 11.3. The loop must not drive the sim, the step control must
   appear, and stepping must still change the state. */
{
  await page.emulateMedia({ reducedMotion: "reduce" });
  await openSim(2);
  const r = await page.evaluate(async () => {
    const { _running } = await import("./js/sims/base.js");
    const sim = document.querySelector("fp-membrane");
    sim.play();
    const drivenByLoop = _running.has(sim);
    const before = sim.describe();
    const steps = getComputedStyle(sim.querySelector(".teach-steps")).display;
    const play = getComputedStyle(sim.querySelector(".teach-play")).display;
    sim.querySelector(".teach-steps button").click();
    return { drivenByLoop, steps, play, changed: sim.describe() !== before || true,
             positionsMoved: sim.parts.some((p) => p.x !== 0) };
  });
  check("under reduced motion the loop never drives the simulation", !r.drivenByLoop, "");
  check("the step-through control replaces autoplay", r.steps !== "none" && r.play === "none",
    `steps=${r.steps} play=${r.play}`);
  const moved = await page.evaluate(() => {
    const sim = document.querySelector("fp-membrane");
    const snapshot = sim.parts.map((p) => p.x);
    sim.querySelector(".teach-steps button").click();
    return sim.parts.some((p, i) => p.x !== snapshot[i]);
  });
  check("stepping advances the mechanism, so every state is still reachable", moved, "");
  await page.emulateMedia({ reducedMotion: "no-preference" });
}

/* 58. Level-indexed parameters: one implementation, different complexity. */
{
  const kinds = {};
  for (const lv of [1, 2, 3, 4]) {
    await openSim(lv);
    kinds[lv] = await page.evaluate(() => document.querySelector("fp-membrane").kinds.length);
  }
  check("the same simulation runs at four complexities",
    kinds[1] === 2 && kinds[2] === 3 && kinds[3] === 5 && kinds[4] === 6,
    `L1 ${kinds[1]}, L2 ${kinds[2]}, L3 ${kinds[3]}, L4 ${kinds[4]} molecule types`);
}

/* 59. Molecules are told apart by shape as well as colour. */
{
  await openSim(4);
  const shapes = await page.evaluate(() =>
    [...document.querySelectorAll(".sim-chip")].map((c) => c.dataset.shape));
  check("every molecule type has its own shape, not only its own colour",
    new Set(shapes).size === shapes.length && shapes.length === 6, shapes.join(","));
}

/* 60. The sim controls are keyboard operable and meet the touch minimum. */
{
  await openSim(2);
  const slider = page.locator("fp-sim fp-slider input, .sim fp-slider input").first();
  const before = await slider.inputValue();
  await slider.focus();
  await page.keyboard.press("ArrowRight");
  const after = await slider.inputValue();
  const box = await slider.boundingBox();
  check("the pore control works from the keyboard", Number(after) === Number(before) + 1, `${before} -> ${after}`);
  check("and meets the level's touch minimum", box.height >= 60 - 0.5, `${box.height}px`);
}

/* 61. A child who cannot hit the goal is not trapped in the lesson. */
{
  await openSim(2);
  const gatedBefore = await page.locator(".next-btn").isDisabled();
  await page.locator(".stage-actions button").click();
  const gatedAfter = await page.locator(".next-btn").isDisabled();
  check("the objective is worth trying for but is not a toll gate",
    gatedBefore && !gatedAfter, `before ${gatedBefore}, after ${gatedAfter}`);
}

/* 62. Reaching the goal really does unlock the stage. */
{
  await openSim(2);
  const unlocked = await page.evaluate(() => new Promise((res) => {
    const sim = document.querySelector("fp-membrane");
    sim.addEventListener("fp:sim-goal", () => res(true), { once: true });
    sim.pore = 4;                        // food fits, poison does not
    for (let i = 0; i < 20000 && !sim.met; i++) sim.step(1 / 60);
    setTimeout(() => res(sim.met), 50);
  }));
  check("meeting the objective fires the goal and unlocks Next", unlocked === true, String(unlocked));
}

/* 63. The rules still hold on a page with a canvas on it. */
{
  await openSim(2);
  await affordanceRule("simulation");
  await overlapAudit("simulation");
  await auditContrast("simulation");
  await page.screenshot({ path: join(SHOTS, "membrane.png") });
}

/* ===================== phase 8: the complete module ===================== */

/* 64. All five lessons are playable to completion at every level. This is the
   flagship-module commitment from the kickoff, tested rather than asserted. */
{
  const report = {};
  for (const lv of [1, 2, 3, 4]) {
    const done = [];
    for (let n = 0; n < 5; n++) {
      await openWith(freshSave({
        level: lv,
        modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: n } },
      }), `#/l/cells/${n}`);
      await page.waitForSelector(".stage");
      for (let i = 0; i < 22; i++) {
        if (await page.locator(".stage--done").count()) break;
        if (!(await page.locator(".stage").count())) break;
        const t = await page.locator(".stage").getAttribute("data-type");
        if (t === "predict") await page.locator(".predict-option").first().click();
        if (t === "check") await page.locator(".quiz-option").first().click();
        if (t === "slider") { await page.locator("fp-slider input").focus(); await page.keyboard.press("End"); }
        if (t === "sim") { await page.waitForSelector(".sim-canvas"); await page.locator(".stage-actions button").click(); }
        if (t === "build") {
          // Assemble it properly, by tap-then-tap, using each slot's own
          // answer — boss slots are unconstrained, so accepts is not there.
          const slots = await page.locator("fp-slot").count();
          for (let k = 0; k < slots; k++) {
            const want = await page.locator("fp-slot").nth(k).getAttribute("data-correct");
            await page.locator(`fp-placeable[data-id="${want}"]`).click();
            await page.locator("fp-slot").nth(k).click();
            await page.waitForTimeout(30);
          }
        }
        await page.waitForTimeout(60);
        const next = page.locator(".next-btn");
        if (!(await next.count()) || await next.isDisabled()) break;
        await next.click();
        await page.waitForTimeout(80);
      }
      if (await page.locator(".stage--done").count()) done.push(n);
    }
    report[lv] = done;
  }
  check("all five lessons are completable at every level",
    [1, 2, 3, 4].every((lv) => report[lv].length === 5),
    [1, 2, 3, 4].map((lv) => `L${lv}:${report[lv].length}/5`).join(" "));
}

/* 65. The boss must be winnable AND losable. Any part fits any job, so the
   stress test grades what the child actually assembled — a boss that
   congratulates you regardless of what you built is a cutscene. */
async function openBoss(lv = 2) {
  await openWith(freshSave({
    level: lv, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 4 } },
  }), "#/l/cells/4");
  await page.waitForSelector(".stage");
  for (let i = 0; i < 6; i++) {
    const t = await page.locator(".stage").getAttribute("data-type");
    if (t === "build") break;
    if (t === "predict") await page.locator(".predict-option").first().click();
    await page.waitForTimeout(50);
    await page.locator(".next-btn").click();
    await page.waitForTimeout(70);
  }
  await page.waitForSelector("fp-board");
}

/** Assemble the boss. `swap` puts two parts in each other's jobs. */
const assemble = (swap = null) => page.evaluate((sw) => {
  const board = document.querySelector("fp-board");
  const slots = board.slots;
  const part = (id) => board.querySelector(`fp-placeable[data-id="${id}"]`);
  for (const slot of slots) {
    let want = slot.dataset.correct;
    if (sw && want === sw[0]) want = sw[1];
    else if (sw && want === sw[1]) want = sw[0];
    board.pickUp(part(want));
    board.place(slot);
  }
  return board.state;
}, swap);

{
  await openBoss();
  await assemble();
  await page.waitForSelector(".trials");
  const passes = await page.locator(".trial--pass").count();
  const fails = await page.locator(".trial--fail").count();
  check("a correct build survives all three stresses", passes === 3 && fails === 0,
    `${passes} passed, ${fails} failed`);
  check("and says so", /survived/i.test(await page.locator(".trial-summary").textContent()), "");
}

/* 66. The diagnostic case. Put the power plant in the wrong job and the two
   trials that needed it must fail, each naming what was missing. */
{
  await openBoss();
  await assemble(["mito", "nucleus"]);
  await page.waitForSelector(".trials");
  const fails = await page.locator(".trial--fail").count();
  const whys = await page.locator(".trial--fail .trial-why").allTextContents();
  check("misassigning the power plant fails exactly the trials that needed it",
    fails === 2, `${fails} failed`);
  check("and each failure explains what was missing",
    whys.every((w) => w.length > 20), whys.map((w) => w.slice(0, 40)).join(" | "));
  const summary = await page.locator(".trial-summary").textContent();
  check("a failed run points at the fix rather than scolding",
    /which|move|try again/i.test(summary), summary.slice(0, 60));
  await page.screenshot({ path: join(SHOTS, "boss.png") });
}

/* 66b. And the child can fix it in place: swap the two back and re-test. */
{
  await assemble();
  await page.waitForTimeout(100);
  check("putting the part in its right job makes the same stress survivable",
    (await page.locator(".trial--fail").count()) === 0,
    `${await page.locator(".trial--pass").count()} now pass`);
}

/* 67. Finishing the module unlocks three worlds — the payoff the Atlas
   dependency graph was built for. */
{
  await openWith(freshSave({
    level: 2,
    modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 5 } },
  }));
  await page.waitForSelector(".islands");
  const unlocked = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    const s = await import("./js/state.js");
    return c.worlds.filter((w) => c.isWorldUnlocked(w, s.progress)).map((w) => w.id);
  });
  check("completing Cells still opens Bodies, The Living World and The Code in the graph",
    ["bodies", "living", "code"].every((w) => unlocked.includes(w)), unlocked.join(", "));
  /* The point is the gap between the two, not a count: the graph opens Bodies
     and The Living World, and the Atlas still refuses to draw them because
     there is nothing in them yet. Asserting a literal here meant the test
     stopped checking that gap the moment a second world was authored. */
  const empty = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    const s = await import("./js/state.js");
    const drawn = new Set(c.playableWorlds().map((w) => w.id));
    // The rule: a world the graph has unlocked is STILL not drawn if it has
    // nothing in it. Naming Bodies and The Living World here broke the moment
    // Human Body was authored — the third literal in this file to do that.
    return {
      unlockedButEmpty: c.worlds
        .filter((w) => c.isWorldUnlocked(w, s.progress) && !c.worldHasContent(w))
        .map((w) => ({ id: w.id, drawn: drawn.has(w.id) })),
      drawnEmpty: c.worlds.filter((w) => drawn.has(w.id) && !c.worldHasContent(w)).map((w) => w.id),
    };
  });
  /* The rule is "no drawn world is empty", and that is never vacuous because
     there are always drawn worlds. The stronger clause — that an unlocked but
     empty world is refused — only applies while such a world exists, so it is
     conditional rather than required. Demanding one exist was the same
     snapshot mistake D52 and D53 are about, made by the fix for them: it
     passed until every unlocked world had content, then failed for the best
     possible reason. The detail line says when the clause went quiet. */
  check("but the Atlas only draws what a child can actually play",
    empty.drawnEmpty.length === 0 && empty.unlockedButEmpty.every((w) => !w.drawn),
    empty.unlockedButEmpty.length
      ? `${empty.unlockedButEmpty.length} unlocked-but-empty, all refused`
      : "every unlocked world now has content — stronger clause not applicable");
}

/* 68. Five lessons means five concepts on the retrieval schedule. */
{
  const concepts = await page.evaluate(async () => {
    const r = await fetch("content/reviews.json");
    return Object.keys(await r.json()).sort();
  });
  check("every concept the module teaches has a review beat",
    concepts.length >= 7, concepts.join(", "));
}

/* 69. The rules hold on the boss too. */
{
  await openWith(freshSave({
    level: 4, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 4 } },
  }), "#/l/cells/4");
  await page.waitForSelector(".stage");
  await affordanceRule("boss");
  await overlapAudit("boss");
  await auditContrast("boss");
}

/* ============ phase 9: Sprout, and phase 10: the real audits ============ */

/* 70. The tutor asks before it tells. Rungs 0-4 must contain no statement of
   the answer; only the last rung states a fact, and only after real struggle. */
{
  await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 1 } } }), "#/l/cells/1");
  await page.waitForSelector(".stage");
  for (let i = 0; i < 8; i++) {
    const t = await page.locator(".stage").getAttribute("data-type");
    if (t === "sim") break;
    if (t === "predict") await page.locator(".predict-option").first().click();
    await page.waitForTimeout(50);
    await page.locator(".next-btn").click();
    await page.waitForTimeout(70);
  }
  await page.waitForSelector("fp-tutor:not([hidden]) .tutor-ask");
  const rungs = [];
  for (let i = 0; i < 6; i++) {
    await page.locator(".tutor-ask").click();
    await page.waitForTimeout(60);
    rungs.push({
      name: await page.locator(".tutor-panel").getAttribute("data-rung"),
      text: await page.locator(".tutor-line").textContent(),
    });
    if (await page.locator(".tutor-ask").isDisabled()) break;
  }
  check("the ladder climbs notice, focus, compare, analogy, partial, consolidate",
    rungs.map((r) => r.name).join(",") === "notice,focus,compare,analogy,partial,consolidate",
    rungs.map((r) => r.name).join(","));
  // The first five rungs must be questions or instructions, never the answer.
  const early = rungs.slice(0, 5).map((r) => r.text);
  check("the first five rungs never state the answer",
    early.every((t) => !/steric|exclusion|because the (holes|size)/i.test(t)),
    early.find((t) => /steric/i.test(t))?.slice(0, 50) ?? "");
  check("only the last rung names the concept",
    /steric|size against hole size|small things through/i.test(rungs.at(-1).text),
    rungs.at(-1).text.slice(0, 60));
  check("and then it stops rather than repeating itself",
    await page.locator(".tutor-ask").isDisabled(), "");
}

/* 71. Struggle is detected, not self-reported. A wrong answer puts Sprout's
   hand up without the child having to declare they need help. */
{
  await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 } } }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  for (let i = 0; i < 10; i++) {
    const t = await page.locator(".stage").getAttribute("data-type");
    if (t === "check") break;
    if (t === "predict") await page.locator(".predict-option").first().click();
    if (t === "slider") { await page.locator("fp-slider input").focus(); await page.keyboard.press("End"); }
    await page.waitForTimeout(50);
    await page.locator(".next-btn").click();
    await page.waitForTimeout(70);
  }
  const nudgedBefore = await page.locator("fp-tutor[data-nudged]").count();
  await page.locator(".quiz-option").nth(2).click();       // wrong
  await page.waitForTimeout(120);
  const nudgedAfter = await page.locator("fp-tutor[data-nudged]").count();
  check("a wrong answer makes Sprout put its hand up, unasked",
    nudgedBefore === 0 && nudgedAfter === 1, `${nudgedBefore} -> ${nudgedAfter}`);
  check("but it never opens itself — the panel stays shut until the child asks",
    await page.locator(".tutor-panel").isHidden(), "");
}

/* 72. Sprout is silent where there is nothing to be stuck on. Offering help on
   a paragraph is noise, and noise is how a companion becomes a nuisance. */
{
  await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 } } }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  const onHook = await page.locator("fp-tutor").isHidden();
  await page.locator(".next-btn").click();
  await page.waitForTimeout(90);
  const onPredict = await page.locator("fp-tutor").isHidden();
  check("no help offered on a hook; help offered on a prediction",
    onHook === true && onPredict === false, `hook hidden=${onHook}, predict hidden=${onPredict}`);
}

/* 73. The ladder resets per stage — carrying a rung across would have Sprout
   answering a question nobody asked. */
{
  await page.locator(".predict-option").first().click();
  await page.locator(".tutor-ask").click();
  await page.waitForTimeout(60);
  const first = await page.locator(".tutor-panel").getAttribute("data-rung");
  await page.locator(".next-btn").click();
  await page.waitForTimeout(120);
  const afterMove = await page.locator(".tutor-panel").isHidden();
  check("the ladder resets when the stage changes",
    first === "notice" && afterMove === true, `${first}, panel hidden after move=${afterMove}`);
}

/* 74. The tutor is level-scaled like everything else. */
{
  const said = {};
  for (const lv of [1, 4]) {
    await openWith(freshSave({ level: lv, modules: { "what-is-life": { lessonsDone: 4 } } }), "#/l/cells/0");
    await page.waitForSelector(".stage");
    await page.locator(".next-btn").click();
    await page.waitForSelector("fp-tutor:not([hidden])");
    await page.locator(".tutor-ask").click();
    await page.waitForTimeout(60);
    said[lv] = await page.locator(".tutor-line").textContent();
  }
  check("Sprout speaks to the child in front of it", said[1] !== said[4],
    `L1 "${said[1].slice(0, 34)}" vs L4 "${said[4].slice(0, 34)}"`);
}

/* 75. Four real breakpoints, straight off the resolver's checklist. Nothing may
   overflow horizontally and every control must still meet its touch minimum. */
{
  const sizes = [[375, 720], [768, 1024], [1024, 768], [1440, 900]];
  const routes = ["#/", "#/m/cells", "#/l/cells/1", "#/me"];
  const problems = [];
  for (const [w, h] of sizes) {
    await page.setViewportSize({ width: w, height: h });
    for (const route of routes) {
      await openWith(freshSave({ level: 2, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 1 } } }), route);
      await page.waitForSelector("main h1, .stage", { state: "attached" });
      await page.waitForTimeout(150);
      const bad = await page.evaluate(() => {
        const out = [];
        if (document.documentElement.scrollWidth > innerWidth + 1) out.push(`page overflows by ${document.documentElement.scrollWidth - innerWidth}px`);
        for (const n of document.querySelectorAll("a[href], button:not(:disabled), fp-placeable, fp-slot")) {
          const r = n.getBoundingClientRect();
          if (!r.width || !r.height) continue;
          if (r.right > innerWidth + 1) out.push(`${n.className || n.tagName} runs off the right`);
          const min = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--touch"));
          if (r.height < min - 1 && !n.closest(".app-bar")) out.push(`${n.className || n.tagName} is ${Math.round(r.height)}px, under the ${min}px minimum`);
        }
        return [...new Set(out)];
      });
      if (bad.length) problems.push(`${w}px ${route}: ${bad[0]}`);
    }
  }
  await page.setViewportSize({ width: 1280, height: 900 });
  check("nothing overflows or shrinks below the touch minimum at 375, 768, 1024 or 1440",
    problems.length === 0, problems.slice(0, 3).join(" | "));
}

/* 76. Landscape phone: the shortest viewport a child will actually hold. */
{
  await page.setViewportSize({ width: 740, height: 360 });
  await openWith(freshSave({ level: 1, modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 1 } } }), "#/l/cells/1");
  await page.waitForSelector(".stage");
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
  check("a landscape phone at level 1 still fits horizontally", overflow <= 1, `${overflow}px over`);
  await page.setViewportSize({ width: 1280, height: 900 });
}

/* ===================== the optimisation patch ===================== */

/* 77. THE HEADLINE FIX. Reading register and conceptual depth are independent.
   A dyslexic fourteen-year-old asking for readable sentences must not be given
   a five-year-old's science — which is exactly what one dial did. */
{
  await openWith({ ...freshSave(), prose: 1, content: 4,
    modules: { "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 1 } } }, "#/l/cells/1");
  await page.waitForSelector(".stage");
  const hook = await page.locator(".stage-hook").textContent();
  const roots = await page.evaluate(() => ({
    level: document.documentElement.dataset.level,
    age: document.documentElement.dataset.age,
    fs: getComputedStyle(document.body).fontSize,
    touch: getComputedStyle(document.documentElement).getPropertyValue("--touch").trim(),
  }));
  check("simple words and hard science can be asked for together",
    roots.level === "1" && roots.age === "4", JSON.stringify(roots));
  check("the prose really is the level-1 wording",
    /A wall keeps everything out/.test(hook), hook.slice(0, 50));

  // and the CONTENT track is the grown-up one: five molecule types, not two
  for (let i = 0; i < 8; i++) {
    const t = await page.locator(".stage").getAttribute("data-type");
    if (t === "sim") break;
    if (t === "predict") await page.locator(".predict-option").first().click();
    await page.waitForTimeout(50);
    await page.locator(".next-btn").click();
    await page.waitForTimeout(70);
  }
  await page.waitForSelector(".sim-canvas");
  const kinds = await page.evaluate(() => document.querySelector("fp-membrane").kinds.length);
  check("while the science stays at the level-4 track", kinds === 6, `${kinds} molecule types`);
}

/* 78. Touch targets follow CONTENT, not prose. A teenager who wants large text
   has adult motor control and does not want 76px buttons. */
{
  await openWith({ ...freshSave(), prose: 1, content: 4 });
  await page.waitForSelector(".islands");
  const big = await page.evaluate(() => ({
    fs: parseFloat(getComputedStyle(document.body).fontSize),
    touch: parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--touch")),
  }));
  await openWith({ ...freshSave(), prose: 4, content: 1 });
  await page.waitForSelector(".islands");
  const small = await page.evaluate(() => ({
    fs: parseFloat(getComputedStyle(document.body).fontSize),
    touch: parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--touch")),
  }));
  check("big text with small targets, and small text with big targets, are both reachable",
    big.fs > small.fs && big.touch < small.touch,
    `prose1/content4: ${big.fs}px text, ${big.touch}px target — prose4/content1: ${small.fs}px, ${small.touch}px`);
}

/* 79. Me exposes both dials and says why they are separate. */
{
  await openWith(freshSave(), "#/me");
  await page.waitForSelector(".choices");
  const legends = await page.locator(".choices legend").allTextContents();
  check("Me offers words and science as two separate settings",
    legends.some((l) => /words/i.test(l)) && legends.some((l) => /science/i.test(l)),
    legends.join(" / "));
  // the radio itself is visually hidden behind its clay box by design; a real
  // child clicks the label, so the test does too
  await page.locator('label:has(input[name="content"][value="4"])').click();
  await page.waitForTimeout(150);
  const after = await page.evaluate(() => ({
    level: document.documentElement.dataset.level, age: document.documentElement.dataset.age }));
  check("changing one dial leaves the other alone",
    after.level === "2" && after.age === "4", JSON.stringify(after));
}

/* 80. One throwing simulation must not take the loop down with it. Before this,
   the next frame was already scheduled at the top of tick(), so a throw meant
   sixty errors a second forever and nothing rendered. */
{
  const r = await page.evaluate(async () => {
    const { Sim, _running } = await import("./js/sims/base.js");
    class Bad extends Sim {
      setup() {} draw() {} describe() { return "bad"; }
      step() { throw new Error("deliberate"); }
    }
    if (!customElements.get("fp-bad")) customElements.define("fp-bad", Bad);
    const bad = document.createElement("fp-bad");
    const good = document.createElement("fp-bad");
    good.step = () => { good.ticks = (good.ticks ?? 0) + 1; };
    // Pin them in the viewport: the off-screen IntersectionObserver would
    // otherwise pause both a moment after they mount, which is correct
    // behaviour and would make this test measure nothing.
    for (const el of [bad, good]) el.style.cssText = "position:fixed;top:0;left:0;width:24px;height:24px;opacity:0";
    document.body.append(bad, good);
    // play() is what joins the shared loop AND starts it; adding to the set
    // directly leaves the rAF unscheduled and nothing ever runs.
    bad.play(); good.play();
    await new Promise((res) => setTimeout(res, 260));
    const out = { badStillRunning: _running.has(bad), goodTicks: good.ticks ?? 0,
                  toldTheChild: !!document.querySelector(".sim-broken") };
    bad.remove(); good.remove(); _running.clear();
    return out;
  });
  check("a broken simulation is evicted rather than killing the loop",
    r.badStillRunning === false && r.goodTicks > 5,
    `evicted=${!r.badStillRunning}, healthy sim ticked ${r.goodTicks} times`);
  check("and it says so recoverably instead of leaving a blank rectangle",
    r.toldTheChild, "");
}

/* 81. The boss announces. It is the climax of the module and it was silent. */
{
  await openBoss();
  await assemble(["mito", "nucleus"]);
  await page.waitForSelector(".trials");
  const spoken = await page.locator("fp-stage p[role=status].sr-only").textContent();
  check("the stress-test result is spoken, not only drawn",
    /1 of 3 stresses survived/.test(spoken) && /failed/.test(spoken), spoken.slice(0, 80));
  await assemble();
  await page.waitForTimeout(120);
  check("and the announcement updates when the child fixes it",
    /All 3 stresses survived/.test(await page.locator("fp-stage p[role=status].sr-only").textContent()), "");
}

/* 82. The level nudge: three lessons of evidence, then one offer, never an
   automatic change. Self-selected difficulty skews upward and this is the
   corrective the blueprint specified and phase 6 never built. */
{
  const r = await page.evaluate(async () => {
    const lv = await import("./js/level.js");
    const st = await import("./js/state.js");
    st.reset();
    lv.setLevels({ prose: 3, content: 3 });
    const none = lv.levelNudge();
    for (let i = 0; i < 3; i++) lv.recordLessonPerformance({ hits: 0, misses: 3, helped: true });
    const down = lv.levelNudge();
    st.reset(); lv.setLevels({ prose: 2, content: 2 });
    for (let i = 0; i < 3; i++) lv.recordLessonPerformance({ hits: 4, misses: 0, helped: false });
    const up = lv.levelNudge();
    return { none, down, up };
  });
  check("no nudge before there is evidence", r.none === null, JSON.stringify(r.none));
  check("three struggling lessons offer a gentler science level",
    r.down?.direction === "down" && r.down.to === 2, JSON.stringify(r.down));
  check("three effortless lessons offer a harder one",
    r.up?.direction === "up" && r.up.to === 3, JSON.stringify(r.up));
  const changed = await page.evaluate(async () => {
    const st = await import("./js/state.js");
    return st.progress.content;
  });
  check("but nothing changed on its own — the offer is the whole mechanism",
    changed === 2, `content is ${changed}`);
}

/* 83. Sprout's ladders are content now, not 9 KB of strings in the bundle. */
{
  const fetched = [];
  const listen = (r) => fetched.push(new URL(r.url()).pathname);
  page.on("request", listen);
  await openWith(freshSave({ modules: { "what-is-life": { lessonsDone: 4 } } }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  await page.locator(".next-btn").click();
  await page.waitForSelector("fp-tutor:not([hidden])");
  await page.locator(".tutor-ask").click();
  await page.waitForTimeout(120);
  page.off("request", listen);
  check("hints are fetched as content rather than compiled in",
    fetched.some((u) => u.endsWith("/content/hints.json")), "");
  check("and Sprout still speaks", (await page.locator(".tutor-line").textContent()).length > 10,
    (await page.locator(".tutor-line").textContent()).slice(0, 40));
}

/* 84. The lesson index is generated, so a link can never point at a file that
   is not there. */
{
  const consistent = await page.evaluate(async () => {
    const c = await import("./js/curriculum.js");
    const entries = Object.entries(c.authored).flatMap(([m, ls]) => Object.entries(ls).map(([i, f]) => [m, i, f]));
    const checks = await Promise.all(entries.map(async ([, , f]) => (await fetch(`content/${f}`)).ok));
    return { n: entries.length, allPresent: checks.every(Boolean) };
  });
  // Counted from disk rather than hard-coded: the last time this was a literal
  // it silently stopped meaning anything the moment a sixth lesson landed.
  const onDisk = Object.values(JSON.parse(readFileSync(join(ROOT, "content/authored.json"), "utf8")))
    .reduce((n, m) => n + Object.keys(m).length, 0);
  check("every lesson the app offers actually exists on disk",
    consistent.n === onDisk && consistent.allPresent, `${consistent.n} of ${onDisk}`);
}

/* ===========================================================================
   85-93. THE FORMAT PAST CELLS.
   Everything above this line was written while the only authored module was
   Cells, and a format proved against one module is a format proved against one
   module. These check the things that broke when a structurally different
   lesson — an episodic simulation and an attributed disagreement — was written
   against it. See DECISIONS D45-D48.
   =========================================================================== */

/* A save with everything upstream of the Change world finished. */
const changeSave = (level) => freshSave({ level, modules: {
  "what-is-life": { lessonsDone: 4 }, cells: { lessonsDone: 5 },
  dna: { lessonsDone: 5 }, genes: { lessonsDone: 4 },
} });

/** Walk a lesson forward until a stage of the given type is on screen. */
async function walkTo(type, limit = 12) {
  for (let i = 0; i < limit; i++) {
    const t = await page.locator(".stage").getAttribute("data-type");
    if (t === type) return true;
    if (t === "predict") await page.locator(".predict-option").first().click();
    if (t === "check") await page.locator(".quiz-option").first().click();
    await page.waitForTimeout(60);
    await page.locator(".next-btn").click();
    await page.waitForTimeout(80);
  }
  return false;
}

/** Mount a selection sim directly, with the reveal made instantaneous so these
    measure the MODEL rather than the animation that shows it. */
const mountSelection = (body) => page.evaluate(async (src) => {
  const { _running } = await import("./js/sims/base.js");
  await import("./js/sims/selection.js");
  document.querySelectorAll("fp-selection").forEach((n) => n.remove());
  const sim = document.createElement("fp-selection");
  Object.assign(sim.dataset, { task: "break", switches: "true", bg: "0.9" });
  document.querySelector("#main").append(sim);
  await new Promise((r) => setTimeout(r, 120));
  sim.reduced = { matches: true };
  const generations = (n) => { for (let i = 0; i < n * 2; i++) sim.next(); };
  // eslint-disable-next-line no-new-func
  return await new Function("sim", "_running", "generations", `return (async () => { ${src} })()`)(sim, _running, generations);
}, body);

/* 85. An episodic sim must not be driven by the shared loop between clicks. */
{
  await openWith(changeSave(3), "#/");
  const r = await mountSelection(`
    return { autoplay: sim.autoplay, inLoop: _running.has(sim), gen: sim.gen };
  `);
  check("an episodic simulation stays out of the shared loop until asked",
    r.autoplay === false && r.inLoop === false && r.gen === 0, JSON.stringify(r));
}

/* 86. THE LESSON ITSELF, as a measurement. With all three conditions on the
   population must track its background; with any one removed it must not. This
   is the only test in the suite that checks a scientific claim rather than a
   piece of software, and it is the one worth having. */
{
  /* Sampled, not single-shot. With differential survival switched off the mean
     still wanders — that is genetic drift, and it is real biology rather than a
     defect — so roughly one run in twenty drifts far enough to look adapted. A
     single-run assertion here failed exactly that way, which made it a flaky
     test of a true claim. Measuring the RATE turns it into a stronger check:
     the claim was never "it can never close" but "it does not reliably close". */
  const N = 24;
  const r = await mountSelection(`
    const closes = () => { sim.reset(); const s = sim.gap; generations(14);
                           return s > 0.18 && sim.gap < s * 0.35; };
    const rate = (setup) => { let hits = 0;
      for (let i = 0; i < ${N}; i++) { setup(); if (closes()) hits++; }
      return hits / ${N}; };
    const all = rate(() => {});
    const off = {};
    for (const key of ["variation", "heredity", "survival"]) {
      off[key] = rate(() => { for (const k of ["variation","heredity","survival"]) sim.on[k] = k !== key; });
    }
    for (const k of ["variation","heredity","survival"]) sim.on[k] = true;
    return { all, off };
  `);
  check("with all three conditions the population reliably adapts",
    r.all >= 0.9, `${Math.round(r.all * 100)}% of ${N} runs`);
  for (const key of ["variation", "heredity", "survival"]) {
    check(`removing ${key} stops adaptation`, r.off[key] <= 0.25,
      `${Math.round(r.off[key] * 100)}% of ${N} runs still closed — drift, not selection`);
  }
}

/* 87. Cross-run state survives reset, which is what makes "run it twice and
   compare" expressible at all. Before once() existed, reset() wiped both the
   trace history and the child's own switch settings. */
{
  const r = await mountSelection(`
    sim.on.heredity = false;
    generations(6);
    sim.reset();
    return { keptRuns: sim.runs.length, keptSwitch: sim.on.heredity, freshTrace: sim.trace.length };
  `);
  check("reset starts a new run without erasing the last one or the hypothesis",
    r.keptRuns >= 1 && r.keptSwitch === false && r.freshTrace === 1, JSON.stringify(r));
}

/* 88. Meeting the objective unlocks the lesson; it does not end the experiment.
   Freezing on success is the exact moment a child most wants to keep poking. */
{
  const r = await mountSelection(`
    let fired = 0, said = null;
    sim.addEventListener("fp:sim-goal", (e) => { fired++; said = e.detail?.say ?? null; });
    /* Run UNTIL the goal is met, not for a fixed twelve generations. Selection is
       stochastic by construction — the test above measures it closing the gap in
       about nine runs out of ten — so "twelve generations" was a coin weighted
       against us, and it came up tails. The claim here has nothing to do with how
       many generations adaptation takes; it is that the goal fires exactly once.
       Say that instead. The cap is a runaway guard, not a deadline. (D75) */
    for (let i = 0; i < 200 && !sim.met; i++) sim.next();
    /* Break it by removing VARIATION, not survival. This test is about the
       event plumbing — does the goal fire once, and does it carry the sim's own
       sentence — so it must not ride on a stochastic outcome. With variation
       off every beetle is identical forever and the gap is pinned at its
       starting value, which satisfies the "still broken" condition with
       certainty. Using survival made this flaky for exactly the reason D52
       describes: drift occasionally closes the gap enough to look like
       progress, and four generations is not many chances. */
    sim.on.variation = false; sim.reset(); generations(8);
    const at = sim.gen;
    sim.next(); sim.next();
    return { fired, said, advancedAfterGoal: sim.gen > at, met: sim.met };
  `);
  check("the goal fires once and carries the simulation's own account of it",
    r.fired === 1 && typeof r.said === "string" && r.said.length > 20, JSON.stringify(r).slice(0, 140));
  check("meeting the goal does not freeze the simulation", r.advancedAfterGoal === true, JSON.stringify(r));
}

/* 89. A weigh stage may not be walked past having read one side. */
{
  await openWith(changeSave(3), "#/l/evolution/0");
  await page.waitForSelector(".stage");
  const reached = await walkTo("weigh");
  check("the evolution lesson reaches its weigh stage at content level 3", reached, "");

  const lockedAtStart = await page.locator(".next-btn").isDisabled();
  await page.locator(".weigh-who").first().click();
  await page.waitForTimeout(120);
  const lockedAfterOne = await page.locator(".next-btn").isDisabled();
  await page.locator(".weigh-who").nth(1).click();
  await page.waitForTimeout(120);
  const lockedAfterBoth = await page.locator(".next-btn").isDisabled();
  check("both readings must be opened before the lesson moves on",
    lockedAtStart && lockedAfterOne && !lockedAfterBoth,
    `start ${lockedAtStart}, one ${lockedAfterOne}, both ${lockedAfterBoth}`);
}

/* 90. Nothing on a weigh stage is asserted in the product's own voice. Every
   view is attributed and every view shows its reasoning — this is the rule the
   whole stage type exists to enforce, so it is checked in the browser and not
   only in the build. */
{
  const r = await page.evaluate(() => [...document.querySelectorAll(".weigh-view")].map((v) => ({
    who: v.querySelector(".weigh-who")?.textContent?.trim() ?? "",
    claim: (v.querySelector(".weigh-claim")?.textContent ?? "").length,
    because: (v.querySelector(".weigh-because")?.textContent ?? "").length,
  })));
  check("every reading is attributed and shows its reasoning",
    r.length >= 2 && r.every((v) => v.who.length > 3 && v.claim > 20 && v.because > 40),
    JSON.stringify(r));
}

/* 91. The two views must not be styled to favour one. A child reads visual
   weight long before they read the words, so an argument made in CSS is an
   argument made behind the author's back. */
{
  const same = await page.evaluate(() => {
    const [a, b] = [...document.querySelectorAll(".weigh-view")].map((v) => {
      const s = getComputedStyle(v);
      return [s.backgroundColor, s.borderTopWidth, s.borderTopColor, s.boxShadow,
              getComputedStyle(v.querySelector(".weigh-who")).fontSize].join("|");
    });
    return a === b;
  });
  check("the two readings are presented with identical visual weight", same, "");
}

/* 92. Reduced motion needs no substitution for an episodic sim, because the
   control is already the child's own click. But the control must still BE
   there — putting it in .teach-play would have hidden it. */
{
  await page.emulateMedia({ reducedMotion: "reduce" });
  await openWith(changeSave(1), "#/l/natural-selection/0");
  await page.waitForSelector(".stage");
  await walkTo("sim");
  await page.waitForSelector("fp-selection .sim-canvas");
  const r = await page.evaluate(() => {
    const sim = document.querySelector("fp-selection");
    const btn = sim.querySelector(".sim-beat");
    const before = sim.gen;
    btn.click(); btn.click();
    return { visible: getComputedStyle(btn).display !== "none", advanced: sim.gen > before,
             label: btn.textContent };
  });
  check("an episodic simulation keeps its control under reduced motion",
    r.visible && r.advanced, JSON.stringify(r));
  await page.emulateMedia({ reducedMotion: "no-preference" });
}

/* 93. A slider whose readout is a bare number tells a five-year-old nothing. */
{
  const readout = await page.evaluate(() => {
    const s = document.querySelector("fp-selection fp-slider");
    return { text: s.querySelector(".slider-value").textContent,
             valuetext: s.querySelector("input").getAttribute("aria-valuetext") };
  });
  check("a worded slider reads as words, in the readout and to a screen reader",
    /[a-z]/i.test(readout.text) && readout.valuetext === readout.text, JSON.stringify(readout));
}

/* 94-95. The folding model, checked as a model.

   The lesson's claim is that the shape falls out of the sequence and nothing
   else. That is only true if the energy function is the one advertised and the
   chain cannot pass through itself — so both are measured here rather than
   trusted. Same reasoning as the selection checks: a simulation a child reasons
   from is a claim about the world, and claims get tested. */
{
  await openWith(changeSave(3), "#/");
  const r = await page.evaluate(async () => {
    await import("./js/sims/folding.js");
    document.querySelectorAll("fp-folding").forEach((n) => n.remove());
    const sim = document.createElement("fp-folding");
    Object.assign(sim.dataset, { seq: "PHHPPHHPPHHP", target: "4" });
    document.querySelector("#main").append(sim);
    await new Promise((res) => setTimeout(res, 120));
    sim.reduced = { matches: true };

    // Only NON-SEQUENTIAL H-H pairs count. Sequence neighbours are touching for
    // a trivial reason and would inflate every score if they were included.
    const extended = sim.contacts();

    // Random pivots must never produce a chain that overlaps itself.
    let overlaps = 0, accepted = 0;
    for (let i = 0; i < 400; i++) {
      const at = 1 + Math.floor(Math.random() * (sim.seq.length - 2));
      sim.cw = Math.random() < 0.5;
      if (sim.pivot(at)) accepted += 1;
      const seen = new Set(sim.pos.map(([x, y]) => `${x},${y}`));
      if (seen.size !== sim.pos.length) overlaps += 1;
    }
    /* A refused pivot must be a complete no-op. Four turns do NOT reliably
       return the chain home — self-avoidance blocks some of them — so the
       property worth guaranteeing is that a blocked move leaves the chain
       byte-identical rather than half-applied. Drive it into a wall and check. */
    sim.reset();
    sim.cw = true;
    let refused = 0, corrupted = 0;
    for (let i = 0; i < 200; i++) {
      const at = 1 + Math.floor(Math.random() * (sim.seq.length - 2));
      const snapshot = JSON.stringify([sim.dirs, sim.pos]);
      if (!sim.pivot(at)) {
        refused += 1;
        if (JSON.stringify([sim.dirs, sim.pos]) !== snapshot) corrupted += 1;
      }
    }
    return { extended, overlaps, accepted, refused, corrupted, best: sim.best };
  });
  check("an extended chain has no buried contacts, and neighbours never count",
    r.extended === 0, `${r.extended} contacts when straight`);
  check("no sequence of pivots can fold the chain through itself",
    r.overlaps === 0 && r.accepted > 50, `${r.overlaps} overlaps in ${r.accepted} accepted moves`);
  check("a blocked fold leaves the chain exactly as it was, never half-moved",
    r.refused > 0 && r.corrupted === 0, `${r.corrupted} corrupted of ${r.refused} refusals`);
  check("random folding finds real contacts, so the authored goals are reachable",
    r.best > 0 && r.best <= 4, `best found ${r.best}, known optimum 4`);
}

/* 96-98. All-or-nothing, measured rather than asserted.

   The whole of Neuroscience lesson 1 rests on one claim: a stronger stimulus
   does not produce a bigger spike. That is a claim about the model, so it gets
   tested like one — the same reasoning as the selection checks. If FitzHugh–
   Nagumo ever stopped behaving this way the lesson would be teaching something
   false, and nothing else in the suite would notice. */
{
  const r = await page.evaluate(async () => {
    await import("./js/sims/spike.js");
    document.querySelectorAll("fp-spike").forEach((n) => n.remove());
    const sim = document.createElement("fp-spike");
    Object.assign(sim.dataset, { task: "threshold", amp: 4 });
    document.querySelector("#main").append(sim);
    await new Promise((res) => setTimeout(res, 120));
    sim.reduced = { matches: true };        // drive it by hand, so this is deterministic

    const probe = (amp) => {
      sim.reset();
      sim.amp = amp;
      sim.poke();
      for (let i = 0; i < 400; i++) sim.step(1 / 60);
      return { amp, spikes: sim.spikes, peak: sim.lastPeak };
    };
    const runs = [2, 4, 5, 6, 8, 10, 12].map(probe);
    // A sustained drive well past the upper edge must go quiet again.
    sim.reset();
    sim.amp = 0;
    sim.current = 16;
    for (let i = 0; i < 900; i++) sim.step(1 / 60);
    const blocked = { spikes: sim.spikes, sinceSpike: +sim.sinceSpike.toFixed(1) };
    return { runs, blocked };
  });

  const fired = r.runs.filter((x) => x.spikes > 0);
  const silent = r.runs.filter((x) => x.spikes === 0);
  check("below threshold a stimulus produces no spike at all",
    silent.length > 0 && silent.every((x) => x.peak == null),
    silent.map((x) => x.amp).join(",") + " silent");
  check("above threshold every spike is the same height, however hard the poke",
    fired.length >= 3 &&
      (Math.max(...fired.map((x) => x.peak)) - Math.min(...fired.map((x) => x.peak))) < 0.15,
    fired.map((x) => `${x.amp}:${x.peak.toFixed(2)}`).join(" "));
  // Too much drive silences it too — depolarisation block, and the reason the
  // open-track lesson asks for a window rather than a curve.
  check("far too much steady drive silences it again rather than firing faster",
    r.blocked.sinceSpike > 3, JSON.stringify(r.blocked));
}

/* 99-100. The leaf trade-off: the maximum has to actually lose.

   Plants lesson 3 tells a child that opening the pores all the way produces
   LESS sugar than a middle setting, because the leaf dries out before the day
   ends. If that ever stopped being true of the model the lesson would be
   teaching a falsehood, and nothing else here would notice. */
{
  const r = await page.evaluate(async () => {
    await import("./js/sims/stomata.js");
    document.querySelectorAll("fp-stomata").forEach((n) => n.remove());
    const sim = document.createElement("fp-stomata");
    Object.assign(sim.dataset, { aperture: 4, target: 100000 });   // never succeed; run the day out
    document.querySelector("#main").append(sim);
    await new Promise((res) => setTimeout(res, 120));
    sim.reduced = { matches: true };
    const day = (aperture) => {
      sim.reset();
      sim.aperture = aperture;
      for (let i = 0; i < 60 * 60 && !sim.dead; i++) sim.step(1 / 60);
      return { aperture, sugar: +sim.sugar.toFixed(0), dead: sim.dead, water: +sim.water.toFixed(0) };
    };
    return [0, 2, 5, 7, 10].map(day);
  });
  const at = (a) => r.find((x) => x.aperture === a);
  check("shutting the pores makes no sugar at all",
    at(0).sugar <= 0, JSON.stringify(at(0)));
  check("opening them all the way kills the leaf, and it ends with less sugar than a middle setting",
    at(10).dead && !at(5).dead && at(10).sugar < at(7).sugar,
    r.map((x) => `${x.aperture}:${x.sugar}${x.dead ? "†" : ""}`).join(" "));
}

/* 101-103. The trophic cascade, measured.

   Ecology lesson 4 tells a child that removing the top predator makes the
   PLANTS crash — two levels down, through a level nobody touched. That is a
   claim about the model, so it is checked rather than trusted. If the
   parameters ever drifted so that the cascade stopped appearing, the lesson
   would be asserting something its own simulation contradicts. */
{
  const r = await page.evaluate(async () => {
    await import("./js/sims/web.js");
    document.querySelectorAll("fp-web").forEach((n) => n.remove());
    const sim = document.createElement("fp-web");
    Object.assign(sim.dataset, { task: "cascade", switches: true });
    document.querySelector("#main").append(sim);
    await new Promise((res) => setTimeout(res, 120));
    sim.reduced = { matches: true };
    const settle = () => {
      sim.reset();
      for (let i = 0; i < 60 * 40 && !sim.settled; i++) sim.step(1 / 60);
      return { P: +sim.P.toFixed(1), H: +sim.H.toFixed(1), C: +sim.C.toFixed(1), settled: sim.settled };
    };
    sim.on = { plants: true, herbivores: true, carnivores: true };
    const full = settle();
    sim.on.carnivores = false;
    const noTop = settle();
    sim.on = { plants: true, herbivores: false, carnivores: false };
    const plantsOnly = settle();
    return { full, noTop, plantsOnly };
  });

  check("a population left alone stops at its carrying capacity",
    r.plantsOnly.settled && Math.abs(r.plantsOnly.P - 100) < 2, JSON.stringify(r.plantsOnly));
  check("the whole web settles rather than oscillating or dying",
    r.full.settled && r.full.P > 1 && r.full.H > 1 && r.full.C > 1, JSON.stringify(r.full));
  check("removing the top predator crashes the plants two levels below it",
    r.noTop.H > r.full.H * 1.5 && r.noTop.P < r.full.P * 0.6,
    `full P${r.full.P} H${r.full.H} -> no-top P${r.noTop.P} H${r.noTop.H}`);
}

/* ===================== phase 11: sound and voice ===================== */

/* 76. Narration reads the SCREEN, not a script. The whole reason there are no
   recorded clips is that a recording goes stale the moment I edit a lesson — so
   the thing to prove is that the text spoken is assembled from the rendered
   stage, in order, and that it excludes what must never be read: button labels,
   the progress bar, and the screen-reader live regions (a live region read
   aloud is the same sentence twice). */
{
  await openWith(freshSave({ level: 1 }), "#/l/what-is-life/0");
  await page.waitForSelector(".stage");
  const said = await page.evaluate(async () => {
    const { proseOf } = await import("./js/audio.js");
    return proseOf(document.querySelector(".stage"));
  });
  const onScreen = await page.locator(".stage-hook").textContent();
  check("narration is assembled from the rendered stage", said.includes(onScreen.trim()), said.slice(0, 70));
  check("narration leaves out controls and live regions",
    !/Read to me|Stop|Next|Step \d+ of/.test(said), said.slice(0, 90));
  // and the control it exposes is raised, because it is touchable
  check("the read control is a raised, labelled button, not an icon",
    await page.evaluate(() => {
      const b = document.querySelector(".read-btn");
      return !!b && /\w/.test(b.textContent) && getComputedStyle(b).boxShadow !== "none";
    }));

  // the check stage's options ARE the question for a child who cannot read them
  await stepLesson(12, "predict");
  const spoken = await page.evaluate(async () => {
    const { proseOf } = await import("./js/audio.js");
    return proseOf(document.querySelector(".stage"));
  });
  const opts = await page.evaluate(() =>
    document.querySelector("[data-options]")?.dataset.options.split("|") ?? []);
  check("a question is read with its options, not just the stem",
    opts.length > 1 && opts.every((o) => spoken.includes(o)), `${opts.length} options`);
}

/* 77. Auto-read is derived from the PROSE dial, not a fixed default — level 1 is
   five years old and largely cannot read the lesson at all, which is the whole
   argument for narration existing. And anything that starts by itself needs a
   stop: WCAG 1.4.2, non-negotiable at AA. */
{
  const state = async (lv, prefs = {}) => {
    await openWith(freshSave({ level: lv, prefs }), "#/l/what-is-life/0");
    await page.waitForSelector(".stage");
    await page.waitForTimeout(150);
    return page.evaluate(() => {
      const b = document.querySelector(".read-btn");
      return b ? { label: b.textContent.trim(), hidden: b.hidden, pressed: b.getAttribute("aria-pressed") } : null;
    });
  };
  const l1 = await state(1), l3 = await state(3), off = await state(1, { voice: "off" });
  check("level 1 starts reading by itself", l1?.pressed === "true", JSON.stringify(l1));
  check("a stop control is showing while it reads by itself",
    l1?.label === "Stop" && l1?.hidden === false, JSON.stringify(l1));
  check("above level 1 it waits to be asked", l3?.pressed === "false" && l3?.label === "Read to me", JSON.stringify(l3));
  check("turning the voice off hides the control", off?.hidden === true, JSON.stringify(off));
}

/* 78. Moving to the next stage must cancel the previous one's narration, or the
   child hears stage 3 while looking at stage 4. */
{
  await openWith(freshSave({ level: 1 }), "#/l/what-is-life/0");
  await page.waitForSelector(".stage");
  const cancelled = await page.evaluate(async () => {
    let cancels = 0;
    const real = speechSynthesis.cancel.bind(speechSynthesis);
    speechSynthesis.cancel = () => { cancels++; real(); };
    document.querySelector(".next-btn").click();
    await new Promise((r) => setTimeout(r, 120));
    return cancels;
  });
  check("changing stage cancels the narration in flight", cancelled > 0, `cancel() called ${cancelled}x`);
}

/* 79. Effects are synthesised, so the proof is that no audio file ships and no
   call can take a lesson down with it. A device with no audio output must be a
   silent lesson, not a broken one. */
{
  const assets = await page.evaluate(() => performance.getEntriesByType("resource")
    .map((r) => r.name).filter((n) => /\.(mp3|ogg|wav|m4a|opus|aac)(\?|$)/i.test(n)));
  check("no audio files are shipped at all", assets.length === 0, assets.slice(0, 3).join(" "));
  const threw = await page.evaluate(async () => {
    const { sfx } = await import("./js/audio.js");
    try {
      for (const n of ["pick", "drop", "right", "wrong", "collect", "badge", "notasound"]) sfx(n);
      return null;
    } catch (e) { return e.message; }
  });
  check("a sound never throws, whatever the device", threw === null, threw ?? "");
}

/* 80. Sound is never the only channel for correctness. The colour rule from
   phase 2 applied to a new modality: a deaf child must lose nothing. */
{
  await openWith(freshSave({ level: 2, prefs: { sound: "off" } }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  await stepLesson(12, "check");
  await page.locator(".quiz-option").nth(2).click();
  const marks = await page.evaluate(() =>
    [...document.querySelectorAll(".quiz-option")].map((b) => b.dataset.mark ?? ""));
  const why = await page.locator(".quiz-why").textContent();
  check("with sound off, correctness is still fully carried on screen",
    marks.includes("correct") && marks.includes("chosen") && why.length > 40,
    `${marks.join("|")} + ${why.length} chars`);
}

/* ===================== phase 12: what one lesson costs ===================== */

/* 81. A lesson downloads the parts its own stages need, and nothing else.
   The tier budget was a SUM for eight phases, so it reported a cost no child
   paid and hid the fact that view.js imported all four custom elements
   statically — every lesson fetched the placement primitive whether it had a
   build stage or not. A byte count cannot catch that; only watching the network
   can. (D69) */
{
  const fetched = async (hash, wait, save = freshSave({ level: 2 })) => {
    const seen = [];
    const listen = (r) => seen.push(new URL(r.url()).pathname);
    await landed();
    await setSave(save);
    page.on("request", listen);
    await page.goto(BASE + hash, { waitUntil: "networkidle" });
    await page.reload({ waitUntil: "networkidle" });
    await page.waitForSelector(wait, { timeout: 8000 });
    await page.waitForTimeout(250);
    page.off("request", listen);
    return seen;
  };

  // cells/0 is hook, predict, slider, name, check, apply — no build stage
  const noBuild = await fetched("#/l/cells/0", ".stage");
  check("a lesson with no build stage never downloads the placement primitive",
    !noBuild.some((u) => /components\/board\.js|parts\/build\.js/.test(u)),
    noBuild.filter((u) => /board|build/.test(u)).join(", "));
  check("it does download the parts it DOES use",
    noBuild.some((u) => /components\/slider\.js/.test(u)) && noBuild.some((u) => /parts\/slider\.js/.test(u)),
    noBuild.filter((u) => /parts\/|components\//.test(u)).map((u) => u.split("/").pop()).join(" "));
  check("a lesson with no sim stage never downloads the sim renderer",
    !noBuild.some((u) => /parts\/sim\.js/.test(u)), "");
  check("no lesson downloads the weigh renderer unless it has one",
    !noBuild.some((u) => /parts\/weigh\.js/.test(u)), "");

  // dna/02 has a build stage, so it must fetch both the renderer and the element
  const withBuild = await fetched("#/l/dna/1", ".stage");
  check("a lesson with a build stage does download it",
    withBuild.some((u) => /parts\/build\.js/.test(u)) && withBuild.some((u) => /components\/board\.js/.test(u)),
    withBuild.filter((u) => /parts\/|components\//.test(u)).map((u) => u.split("/").pop()).join(" "));

  /* The review flow was inside view.js, so every lesson shipped the whole
     spaced-retrieval screen and every review shipped nine stage renderers. */
  /* The review route needs something due or it renders the empty-queue notice.
     These ids come from reviews.json, so the beats really exist. */
  const due = {};
  for (const c of ["form-follows-constraint", "surface-area-to-volume"]) {
    due[c] = { step: 0, ease: 1, reps: 1, lapses: 0, due: Date.now() - 864e5, lastGrade: 1 };
  }
  const rev = await fetched("#/review", ".stage-host", freshSave({ level: 2, concepts: due }));
  check("the review flow does not download the lesson runner",
    !rev.some((u) => /lesson\/view\.js|parts\//.test(u)),
    rev.filter((u) => /lesson\//.test(u)).map((u) => u.split("/").pop()).join(" "));
  check("and a lesson does not download the review flow",
    !noBuild.some((u) => /lesson\/review\.js/.test(u)), "");
}

/* ===================== phase 13: the way out ===================== */

/* 82. Reported by a user: "Finish doesn't do anything." It did something —
   `hidden` was set on it and `hidden` was being ignored app-wide, because the
   attribute is only a UA-stylesheet rule and every button here sets display in
   an author rule. So a dead button sat next to a working link that said the same
   thing, and each press called completeLesson again and paid the 12 XP bonus
   once per click. Farmable XP through a CSS bug. (D70) */
{
  await openWith(freshSave({ level: 2 }), "#/l/cells/0");
  await page.waitForSelector(".stage");
  await stepLesson(16);
  await page.waitForSelector(".stage--done");

  const lying = await page.evaluate(() => [...document.querySelectorAll("[hidden]")]
    .filter((n) => shown(n))
    .map((n) => n.className || n.tagName));
  check("nothing marked hidden is still on screen", lying.length === 0, lying.join(", "));

  /* Every visible control on the screen, not just the nav row — the nav row is
     not where the next stray control will be.

     `getClientRects()`, NOT `getComputedStyle(el).display`. A child of a hidden
     parent still reports its own display as inline-flex, so the first version of
     this check reported Sprout's "I'm stuck" button as visible on a finished
     lesson when it was not — I made the exact mistake D70 is about, inside the
     test written to catch it. An element that renders no boxes is not on screen,
     whatever it believes about itself. */
  const exits = await page.evaluate(() =>
    [...document.querySelectorAll(".stage-wrap button, .stage-wrap a")]
      .filter((b) => shown(b)).map((b) => b.textContent.trim()));
  check("a finished lesson shows exactly one control, and it is the way out",
    exits.length === 1, JSON.stringify(exits));
  check("and it says where it goes", /Cells/.test(exits[0] ?? ""), exits[0] ?? "(none)");

  await page.locator(".next-btn").click();
  await page.waitForTimeout(250);
  check("pressing it returns to the module",
    /#\/m\/cells$/.test(await page.evaluate(() => location.hash)),
    await page.evaluate(() => location.hash));
}

/* 83. And the guard underneath it: the completion bonus is paid once per lesson,
   ever. Tested on the real module rather than through the UI, because the UI can
   only reach it one way and the next bug will not. */
{
  await openWith(freshSave({ level: 2 }));
  await page.waitForSelector(".islands");
  const paid = await page.evaluate(async () => {
    const { completeLesson } = await import("./js/reward.js");
    const { progress } = await import("./js/state.js");
    const start = progress.xp;
    completeLesson("cells", 0, { concepts: [], specimen: null });
    const once = progress.xp - start;
    for (let i = 0; i < 4; i++) completeLesson("cells", 0, { concepts: [], specimen: null });
    return { once, afterFiveCalls: progress.xp - start };
  });
  check("finishing a lesson pays the completion bonus once, not once per click",
    paid.once > 0 && paid.afterFiveCalls === paid.once, JSON.stringify(paid));
}

/* ===================== phase 14: the specimen drawings ===================== */

/* 84. A drawing is the reward for collecting the thing, so it must appear for a
   collected specimen and NOT for an uncollected one — seeing it is the reveal.
   And it must be drawn in the world's own colour rather than a colour baked into
   the file, which is what lets one set of paths serve six worlds and two themes. */
{
  const got = ["scale-lens", "membrane", "nucleus"];
  await openWith(freshSave({ level: 2, specimens: got }), "#/me");
  await page.waitForSelector(".specimen--got", { timeout: 8000 });
  await page.waitForSelector(".specimen-art", { timeout: 8000 });
  const seen = await page.evaluate(() => ({
    onGot: [...document.querySelectorAll(".specimen--got")]
      .filter((li) => li.querySelector(".specimen-art")).length,
    gotTotal: document.querySelectorAll(".specimen--got").length,
    onMissing: [...document.querySelectorAll(".specimen:not(.specimen--got)")]
      .filter((li) => li.querySelector(".specimen-art")).length,
    stroke: getComputedStyle(document.querySelector(".specimen-art")).stroke,
    fill: getComputedStyle(document.querySelector(".specimen-art")).fill,
  }));
  check("every collected specimen with art shows it",
    seen.onGot === seen.gotTotal && seen.gotTotal === 3, JSON.stringify(seen));
  check("an uncollected specimen shows no drawing — the reveal is the reward",
    seen.onMissing === 0, `${seen.onMissing} leaked`);
  check("the drawing takes the world's colour and is stroke-only",
    seen.stroke !== "none" && seen.fill === "none", `stroke ${seen.stroke}, fill ${seen.fill}`);
}

/* 85. And the shelf must be complete without any art at all. A picture is a
   reward, never a prerequisite for reading about the thing you collected. */
{
  /* Aborting the request is not enough: this is a PWA and the file is precached,
     so the service worker answers it without touching the network — which is the
     app being right and the test's premise being wrong. The worker has to go
     first for "unreachable" to mean anything. */
  await openWith(freshSave({ level: 2, specimens: ["scale-lens"] }), "#/me");
  await page.evaluate(async () => {
    const regs = await navigator.serviceWorker.getRegistrations();
    await Promise.all(regs.map((r) => r.unregister()));
  });
  breakingNetwork = true;
  await page.route("**/specimen-art.json", (r) => r.abort());
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".specimen--got", { timeout: 8000 });
  await page.waitForTimeout(400);
  const readable = await page.evaluate(() => {
    const li = document.querySelector(".specimen--got");
    return { title: li.querySelector(".specimen-title")?.textContent ?? "",
             unlocks: (li.querySelector(".specimen-unlocks")?.textContent ?? "").length,
             art: li.querySelectorAll(".specimen-art").length };
  });
  check("with the art unreachable the shelf is still complete",
    readable.title === "Scale Lens" && readable.unlocks > 0 && readable.art === 0,
    JSON.stringify(readable));
  await page.unroute("**/specimen-art.json");
  breakingNetwork = false;
}

/* 86. A screen that cannot render must SAY so. A missing import in the lazily
   loaded Me screen rendered a blank page with no console error and no clue — the
   router awaited the view and mounted whatever came back, including nothing. It
   took calling the function by hand in a browser to find. (D73) */
{
  await openWith(freshSave({ level: 2 }));
  await page.waitForSelector(".islands");
  breakingNetwork = true;
  await page.route("**/js/me.js", (r) => r.abort());
  await page.evaluate(async () => {
    const regs = await navigator.serviceWorker.getRegistrations();
    await Promise.all(regs.map((r) => r.unregister()));
  });
  await page.goto(BASE + "#/me", { waitUntil: "networkidle" });
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForTimeout(600);
  const said = await page.evaluate(() => document.querySelector("main")?.innerText ?? "");
  check("a screen that cannot load says so instead of going blank",
    said.trim().length > 20 && /did not load/i.test(said), said.slice(0, 70));
  check("and it still offers a way out",
    await page.locator('main a[href="#/"]').count() > 0);
  await page.unroute("**/js/me.js");
  breakingNetwork = false;
}

/* 87. The shelf groups by world, and a world with nothing in it stays shut. Flat,
   thirteen filled cards were followed by ninety-seven identical grey ones. */
{
  await openWith(freshSave({ level: 2, specimens: ["scale-lens", "membrane", "nucleus"] }), "#/me");
  await page.waitForSelector(".shelf-world", { timeout: 8000 });
  const shelf = await page.evaluate(() => ({
    worlds: document.querySelectorAll(".shelf-world").length,
    open: [...document.querySelectorAll(".shelf-world")].filter((d) => d.open).length,
    visibleCards: [...document.querySelectorAll(".specimen")].filter((n) => shown(n)).length,
    count: document.querySelector(".shelf-count")?.textContent ?? "",
  }));
  check("the shelf is grouped by world, not one flat list of 110",
    shelf.worlds >= 6, JSON.stringify(shelf));
  check("only the world you have collected from is open",
    shelf.open === 1, `${shelf.open} open of ${shelf.worlds}`);
  check("so the empty ninety-seven are not a wall of grey",
    shelf.visibleCards < 20, `${shelf.visibleCards} cards on screen`);
  check("and the shelf says how many you have", /\b3 of \d+/.test(shelf.count), shelf.count);
}

/* 88. The Atlas with something DUE, at every width — the exact state the review
   reminder is drawn in, and the one no screen in this suite had ever rendered. */
{
  const overdue = {};
  for (const c of ["form-follows-constraint", "surface-area-to-volume", "locomotion-tradeoffs"]) {
    overdue[c] = { step: 0, ease: 1, reps: 1, lapses: 0, due: Date.now() - 864e5, lastGrade: 1 };
  }
  for (const w of [320, 390, 768, 1280]) {
    await page.setViewportSize({ width: w, height: 900 });
    await openWith(freshSave({ level: 2, concepts: overdue }));
    await page.waitForSelector(".review-call");
    await overlapAudit(`Atlas with reviews due, ${w}px`);
  }
  await page.setViewportSize({ width: 1280, height: 900 });
}

/* 89. A YEAR OF WORK SURVIVES A CLEARED BROWSER. Everything is stored on the
   device and nowhere else, which is what keeps it private and is also exactly
   why clearing browsing data used to erase it with no way back. The claim is
   that a parent can save a file and hand it back, so the test saves the file,
   genuinely wipes localStorage, and hands it back. (D79) */
{
  const full = freshSave({ level: 2, xp: 340, content: 3,
    modules: { "what-is-life": { lessonsDone: 4 } },
    specimens: ["scale-lens", "membrane", "nucleus"],
    prefs: { theme: "dark", greeted: "1" } });
  await openWith(full, "#/me");
  await page.waitForSelector(".keep-row");

  const [dl] = await Promise.all([
    page.waitForEvent("download"),
    page.locator(".keep-row .keep-btn").first().click(),
  ]);
  const file = await dl.path();
  const saved = JSON.parse(readFileSync(file, "utf8"));
  check("the save can be written to a file", saved.xp === 340 && saved.specimens.length === 3,
    `${dl.suggestedFilename()} — xp ${saved.xp}`);
  check("and the file is named so a parent can find it later",
    /^first-principles-\d{4}-\d{2}-\d{2}\.json$/.test(dl.suggestedFilename()), dl.suggestedFilename());

  // the disaster this exists for
  await page.evaluate(() => localStorage.clear());
  await openWith(freshSave({ level: 2, prefs: { greeted: "1" } }), "#/me");
  await page.waitForSelector(".keep-row");
  const before = await getSave();
  check("clearing the browser really does erase it", before.xp === 0 && !before.specimens.length,
    JSON.stringify({ xp: before.xp, specimens: before.specimens.length }));

  await page.locator(".keep-row input[type=file]").setInputFiles(file);
  await page.waitForTimeout(700);
  const back = await getSave();
  check("and handing the file back restores it exactly",
    back.xp === 340 && back.specimens.length === 3 && back.prefs.theme === "dark" && back.content === 3,
    JSON.stringify({ xp: back.xp, specimens: back.specimens.length, theme: back.prefs.theme, content: back.content }));

  /* A HALF-APPLIED IMPORT IS WORSE THAN A REFUSED ONE. Parse and migrate in full
     before writing anything, so a truncated or foreign file leaves the child
     exactly as they were rather than partly overwritten. */
  await openWith(full, "#/me");
  await page.waitForSelector(".keep-row");
  const junk = join(tmpdir(), "fp-not-a-save.json");
  writeFileSync(junk, "{ this is not json ");
  await page.locator(".keep-row input[type=file]").setInputFiles(junk);
  await page.waitForTimeout(400);
  const said = await page.locator("#keep-said").textContent();
  check("a file that is not a save says so plainly", /not one of ours|not readable/i.test(said ?? ""),
    (said ?? "").slice(0, 60));
  check("and the child's progress is untouched by it", (await getSave()).xp === 340, "");

  /* A save from a LATER version cannot be migrated backwards; pretending
     otherwise would silently drop whatever the newer version knew about. */
  const future = join(tmpdir(), "fp-from-the-future.json");
  writeFileSync(future, JSON.stringify({ ...full, version: 99, xp: 1 }));
  await page.locator(".keep-row input[type=file]").setInputFiles(future);
  await page.waitForTimeout(400);
  check("a save from a newer version is refused, not half-read",
    /newer version/i.test(await page.locator("#keep-said").textContent() ?? "")
      && (await getSave()).xp === 340, "");
}

check("no console errors anywhere", errors.length === 0,
  [...errors.slice(0, 3), ...(failedRequests.length ? [`failed requests: ${failedRequests.slice(0, 4).join(", ")}`] : [])].join(" | "));

await browser.close();
server.close();

const w = Math.max(...results.map((r) => r.name.length));
let bad = 0;
for (const r of results) {
  if (!r.pass) bad++;
  console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.name.padEnd(w)}  ${r.detail}`);
}
console.log(`\n${results.length - bad}/${results.length} passed`);
process.exit(bad ? 1 : 0);
